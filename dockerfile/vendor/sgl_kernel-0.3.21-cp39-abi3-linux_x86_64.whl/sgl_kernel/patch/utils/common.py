'''common'''
import logging
import subprocess
import pkg_resources
import torch
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    Protocol,
    Set,
    Tuple,
    TypeVar,
    Union,
)
import os
import psutil

_is_kunlun = False
try:
    import torch_xmlir
    _is_kunlun = True
except Exception:
    pass

logger = logging.getLogger(__name__)


def is_kunlun() -> bool:
    """Return whether it is Kunlun on the Kunlun platform."""
    return _is_kunlun


def get_nvgpu_memory_capacity_kunlun():
    '''mock nvidia-smi'''
    # TODO: this function returns None. Fix this
    try:
        xpusmi_path = (
            pkg_resources.get_distribution("xmlir").location + "/torch_xmlir/xre/bin"
        )
        logger.info(f"xpusmi_path {xpusmi_path}")
        result = subprocess.run(
            [
                f"{xpusmi_path}/xpu-smi \
                | awk '/^\| *[0-9]+ +P[0-9]00 OAM/{{getline; gsub(/.*\/ |\MiB.*/, \"\"); print}}'"
            ],
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "xpu-smi not found. Ensure Kunlun drivers are installed and accessible."
        )


def support_triton_kunlun(backend: str) -> bool:
    '''support_triton_kunlun'''
    return (not _is_kunlun) and (backend not in ["torch_native", "intel_amx"])

def _get_gpu_numa_node(gpu_id: int) -> int:
    """
        get numa info by gpu_id
    """
    gpu_numa_node = 0
    gpu_idx_in_numa = 0
    gpu_count_in_numa = 0
    try:
        result = subprocess.run(['xpu-smi', 'topo', '-m'],
                            capture_output=True, text=True, check=True)
        lines = result.stdout.splitlines()
        header = lines[0].split()
        numa_col_idx = header.index("NUMA") if "NUMA" in header else -1
        if numa_col_idx == -1:
            numa_col_idx = header.index("NUMA Affinity")

        for line in lines[1:]:
            if not line.strip():
                continue
            parts = line.split()
            if parts[0] == f'XPU{gpu_id}':
                gpu_numa_node = int(parts[numa_col_idx])

        for line in lines[1:]:
            if not line.strip():
                continue
            parts = line.split()
            if parts[0].startswith('XPU'):
                if int(parts[numa_col_idx]) == gpu_numa_node:
                    if int(parts[0].split('XPU')[1]) == gpu_id:
                        gpu_idx_in_numa = gpu_count_in_numa
                    gpu_count_in_numa += 1

        return gpu_numa_node, gpu_idx_in_numa, gpu_count_in_numa

    except Exception as e:
        print(f"Failed to get NUMA node: {e}")
        return 0, 0, 1

def _get_numa_cores(node: int) -> List[int]:
    """
        get cpu list by numa node
    """
    try:
        result = subprocess.run(['lscpu'],
                              capture_output=True, text=True, check=True)
        output = result.stdout
        for line in output.splitlines():
            if line.startswith(f'NUMA node{node} CPU(s):'):
                cpu_ranges = line.split(':')[1].strip()
                break
        else:
            raise ValueError(f"NUMA node {node} not found")
        core_ids = []
        for part in cpu_ranges.split(','):
            if '-' in part:
                start, end = map(int, part.split('-'))
                core_ids.extend(range(start, end + 1))
            else:
                core_ids.append(int(part))
        return core_ids
    except Exception as e:
        print(f"Failed to get NUMA cores: {e}")
        return list(range(psutil.cpu_count(logical=False)))

def set_gpu_proc_affinity_xpu(
    tp_size: int,
    nnodes: int,
    gpu_id: int,
):
    """
        gpu_id: curret device id
    """
    pid = os.getpid()
    p = psutil.Process(pid)

    # get numa info
    gpu_numa_node, gpu_idx_in_numa, gpu_count_in_numa = _get_gpu_numa_node(gpu_id)
    cores = _get_numa_cores(gpu_numa_node)

    # get bind cpu range
    core_per_gpu = len(cores) // gpu_count_in_numa
    start_idx = gpu_idx_in_numa * core_per_gpu
    bind_cores = cores[start_idx : start_idx + core_per_gpu]

    # set cpu affinity
    p.cpu_affinity(bind_cores)
    logger.info(f"Process {pid} gpu_id {gpu_id} is running on CPUs: {p.cpu_affinity()}")


def apply_utils_common_patch():
    """patch"""
    try:
        import sglang.srt.utils.common as utils_common

        utils_common.get_nvgpu_memory_capacity = get_nvgpu_memory_capacity_kunlun
        utils_common.support_triton = support_triton_kunlun
        utils_common.set_gpu_proc_affinity = set_gpu_proc_affinity_xpu 
        print("[Patch] sglang.srt.utils.common.get_nvgpu_memory_capacity -> \
            sgl_kernel.patch.utils.common.get_nvgpu_memory_capacity_kunlun  \
            sglang.srt.utils.common.set_gpu_proc_affinity -> \
            sgl_kernel.patch.utils.common.set_gpu_proc_affinity_xpu")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_utils_common_patch()
