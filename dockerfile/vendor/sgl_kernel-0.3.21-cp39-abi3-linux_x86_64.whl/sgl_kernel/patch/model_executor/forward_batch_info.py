"""forward_batch_info"""

import torch
import xspeedgate_ops
from sglang.srt.utils.common import ceil_align
from sglang.srt.model_executor.model_runner import ModelRunner
from sglang.srt.layers.dp_attention import (
    DpPaddingMode,
    get_attention_dp_rank,
    get_attention_tp_size,
    set_dp_buffer_len,
    set_is_extend_in_batch,
)
from sglang.srt.model_executor.forward_batch_info import ForwardBatch, ForwardMode
from sglang.srt.layers.attention.nsa.utils import is_nsa_enable_prefill_cp

def compute_position_triton(
    extend_prefix_lens: torch.Tensor, extend_seq_lens: torch.Tensor, extend_seq_lens_sum
):
    """Compute positions. It is a fused version of `compute_position_torch`."""

    positions, extend_start_loc = torch.ops.xspeedgate_ops.compute_position_kernel(
        extend_prefix_lens,
        extend_seq_lens,
        extend_seq_lens_sum,
    )
    return positions.to(torch.int64), extend_start_loc

def prepare_mlp_sync_batch(self, model_runner: ModelRunner):
    """Prepare mlp sync batch."""
    from sglang.srt.batch_overlap.two_batch_overlap import TboForwardBatchPreparer

    assert self.global_num_tokens_cpu is not None
    assert self.global_num_tokens_for_logprob_cpu is not None

    global_num_tokens = self.global_num_tokens_cpu
    sync_group_size = len(global_num_tokens)
    attn_tp_size = get_attention_tp_size()

    for i in range(sync_group_size):
        # make sure that the padded length is divisible by attn_tp_size 
        # because we may need reduce-scatter across attn_tp dim.
        # there is no reduce-scatter in LM logprob, 
        # so we do not need to adjust the padded length for logprob
        global_num_tokens[i] = ceil_align(global_num_tokens[i], attn_tp_size)

    dp_padding_mode = DpPaddingMode.get_dp_padding_mode(
        self.is_extend_in_batch, global_num_tokens
    )
    self.dp_padding_mode = dp_padding_mode

    if dp_padding_mode.is_max_len():
        # when DP gather mode is all gather, we will use
        # all_gather_into_tensor to gather hidden states, where transferred
        # tokens should be padded to the same length. We will also use
        # reduce-scatter instead of all-reduce after MLP.
        max_num_tokens = max(global_num_tokens)
        global_num_tokens = [max_num_tokens] * sync_group_size
        buffer_len = max_num_tokens * sync_group_size
    else:
        buffer_len = sum(global_num_tokens)

    if len(global_num_tokens) > 1:
        num_tokens = global_num_tokens[get_attention_dp_rank()]
    else:
        num_tokens = global_num_tokens[0]

    self.global_dp_buffer_len = buffer_len
    set_dp_buffer_len(
        buffer_len, num_tokens, dp_padding_mode.is_max_len(), global_num_tokens
    )
    set_is_extend_in_batch(self.is_extend_in_batch)

    bs = self.batch_size

    if (
        self.forward_mode.is_decode()
        or self.forward_mode.is_target_verify()
        or self.forward_mode.is_draft_extend(include_v2=True)
        or self.forward_mode.is_idle()
    ):
        if self.is_extend_in_batch and dp_padding_mode.is_max_len():
            setattr(self, "_original_forward_mode", self.forward_mode)
            self.forward_mode = ForwardMode.EXTEND
            self.extend_num_tokens = bs
            self.extend_seq_lens = torch.full_like(self.seq_lens, 1)
            self.extend_prefix_lens = self.seq_lens - 1
            self.extend_start_loc = torch.arange(
                bs, dtype=torch.int32, device=self.seq_lens.device
            )
            self.extend_prefix_lens_cpu = self.extend_prefix_lens.cpu()
            self.extend_seq_lens_cpu = self.extend_seq_lens.cpu()
            self.extend_logprob_start_lens_cpu = self.extend_prefix_lens_cpu
        else:
            setattr(self, "_original_batch_size", self.batch_size)
            if self.spec_info is not None:
                bs = self.batch_size = (
                    num_tokens // self.spec_info.num_tokens_per_req
                )
            else:
                bs = self.batch_size = num_tokens
    elif self.forward_mode.is_extend():
        self.extend_num_tokens = num_tokens

    # padding
    self._pad_inputs_to_size(model_runner, num_tokens, bs)
    self.global_num_tokens_cpu = global_num_tokens
    global_num_tokens_pinned = torch.tensor(global_num_tokens, pin_memory=True)
    self.global_num_tokens_gpu.copy_(global_num_tokens_pinned, non_blocking=True)

    TboForwardBatchPreparer.prepare(
        batch=self, is_draft_worker=model_runner.is_draft_worker
    )
    # TODO: The following is added to make sure sub-batch input_ids are padded
    # to the multiple of attn_tp_size. It can likely be removed after this
    # function is refactored and merged into the Scheduler.
    if self.tbo_children:
        for child in self.tbo_children:
            child._pad_inputs_to_size(
                model_runner, child.tbo_padded_len, child.batch_size
            )

def apply_forward_batch_info_patch():
    """patch"""
    try:
        import sglang.srt.model_executor.forward_batch_info as forward_batch_info

        forward_batch_info.compute_position_triton = compute_position_triton
        ForwardBatch.prepare_mlp_sync_batch = prepare_mlp_sync_batch
        print("[Patch] sglang.srt.model_executor.forward_batch_info.compute_position_triton -> \
            sgl_kernel.patch.model_executor.forward_batch_info.compute_position_triton")
        print("[Patch] sglang.srt.model_executor.forward_batch_info.ForwardBatch.prepare_mlp_sync_batch -> \
            sgl_kernel.patch.model_executor.forward_batch_info.prepare_mlp_sync_batch")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_forward_batch_info_patch()

