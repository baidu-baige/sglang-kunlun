"""patch model_executor
"""
