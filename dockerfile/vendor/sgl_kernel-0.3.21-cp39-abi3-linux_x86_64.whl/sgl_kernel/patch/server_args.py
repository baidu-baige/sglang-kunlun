"""patch for server_args"""
import logging
from sgl_kernel.patch.utils.common import is_kunlun

logger = logging.getLogger(__name__)

ATTENTION_BACKEND_CHOICES_KUNLUN = ["kunlun"]


def _handle_page_size_kunlun(self):
    if self.page_size is None:
        if is_kunlun():
            self.page_size = 128
            logger.warning(
                f"Page size is not specified for Kunlun devices, setting it to {self.page_size}."
            )
        else:
            self.page_size = 1


def apply_args_patch():
    """
    apply_args_patch
    """
    try:
        import sglang.srt.server_args as server_args
        from sglang.srt.server_args import ServerArgs
        
        server_args.ATTENTION_BACKEND_CHOICES += ATTENTION_BACKEND_CHOICES_KUNLUN
        ServerArgs._handle_page_size = _handle_page_size_kunlun
        print("[Patch] ServerArgs._handle_page_size patched successfully.")
    except ImportError as e:
        print(f"[Patch Error] Failed to patch ServerArgs._handle_page_size: {e}")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")


apply_args_patch()
