"""patch for xgrammar backend"""
import torch


# adapted from 
# https://github.com/mlc-ai/xgrammar/blob/v0.1.30/python/xgrammar/kernels/apply_token_bitmask_inplace_torch_compile.py#L7
@torch.compile(dynamic=True)
def apply_token_bitmask_inplace_kernel_no_indices_torch_compile(
    logits: torch.Tensor, bitmask: torch.Tensor, vocab_size: int
) -> None:
    """apply_token_bitmask_inplace_kernel_no_indices_torch_compile"""
    # logits: (batch_size, vocab_size)
    # bitmask: (batch_size, bitmask_size)
    # mask_expanded: (batch_size, 32 * bitmask_size)
    mask_expanded = torch.repeat_interleave(bitmask, 32, dim=-1)
    # bit_indices: (32 * bitmask_size,)
    bit_indices = torch.arange(32, device=logits.device, dtype=torch.int32).repeat(
        bitmask.shape[-1]
    )
    # bit_masks: (batch_size, 32 * bitmask_size)
    bit_masks = (mask_expanded >> bit_indices) & 1
    bit_masks = bit_masks[..., :vocab_size]
    logits[..., :vocab_size] = logits[..., :vocab_size].masked_fill_(bit_masks == 0, float("-inf"))


def apply_vocab_mask(self, logits: torch.Tensor, vocab_mask: torch.Tensor) -> None:
    """patch for apply_vocab_mask"""
    # for kunlun
    vocab_size = min(logits.shape[-1], vocab_mask.shape[-1] * 32)
    return apply_token_bitmask_inplace_kernel_no_indices_torch_compile(logits, vocab_mask, vocab_size)

    # if (
    #     logits.device.type == "cuda"
    #     or logits.device.type == "npu"
    #     or logits.device.type == "xpu"
    # ):
    #     if _is_hip:
    #         apply_token_bitmask_inplace_cuda(logits, vocab_mask)
    #     else:
    #         apply_token_bitmask_inplace_triton(logits, vocab_mask)
    # elif logits.device.type == "cpu" and self.apply_vocab_mask_cpu:
    #     self.apply_vocab_mask_cpu(logits, vocab_mask)
    # else:
    #     raise RuntimeError(f"Unsupported device: {logits.device.type}")


def apply_xgrammar_patch():
    """apply xgrammar patch"""
    try:
        from sglang.srt.constrained.xgrammar_backend import XGrammarGrammar

        XGrammarGrammar.apply_vocab_mask = apply_vocab_mask

        print("[Patch] XGrammarGrammar.apply_vocab_mask patched successfully.")

    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")


apply_xgrammar_patch()