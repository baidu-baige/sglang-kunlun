"""new environ
"""
from sglang.srt.environ import EnvBool, EnvField

# Temporarily enable _allow_set_name for class definition
original_allow_set_name = EnvField._allow_set_name
EnvField._allow_set_name = True

class Envs:
    """new environ
    """
    USE_FAST_ALLOC_EXTEND_KUNLUN = EnvBool(True)

envs = Envs()

# Restore the original value
EnvField._allow_set_name = original_allow_set_name

