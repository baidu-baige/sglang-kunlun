"""patch for dp attention
"""
import torch
import xspeedgate_ops

from sglang.srt.distributed import (
    get_tensor_model_parallel_rank,
    get_tp_group,
    GroupCoordinator,
    get_tensor_model_parallel_world_size,
    tensor_model_parallel_all_reduce
)
from sglang.srt.layers.dp_attention import (
    compute_dp_attention_world_info,
    compute_dp_attention_local_info,
    _DpGatheredBufferWrapper,
    get_dp_local_info,
    get_attention_tp_rank
)
import sglang.srt.layers.dp_attention as dp_attention_module

def initialize_dp_attention(
    server_args: "ServerArgs",
    model_config: "ModelConfig",
):
    """initialize_dp_attention"""
    from sglang.srt.layers.sampler import SYNC_TOKEN_IDS_ACROSS_TP

    enable_dp_attention = server_args.enable_dp_attention
    tp_size = server_args.tp_size
    dp_size = server_args.dp_size
    moe_dense_tp_size = server_args.moe_dense_tp_size
    pp_size = server_args.pp_size

    tp_rank = get_tensor_model_parallel_rank()

    dp_attention_module._ENABLE_DP_ATTENTION_FLAG = enable_dp_attention

    dp_attention_module._ATTN_TP_RANK, \
    dp_attention_module._ATTN_TP_SIZE, \
    dp_attention_module._ATTN_DP_RANK = compute_dp_attention_world_info(
        enable_dp_attention, tp_rank, tp_size, dp_size
    )
    _, _, dp_attention_module._LOCAL_ATTN_DP_RANK = compute_dp_attention_local_info(
        enable_dp_attention, tp_rank, tp_size, dp_size, moe_dense_tp_size
    )

    if enable_dp_attention:
        dp_attention_module._ATTN_DP_SIZE = dp_size
        if moe_dense_tp_size is None:
            dp_attention_module._LOCAL_ATTN_DP_SIZE = dp_attention_module._ATTN_DP_SIZE
        else:
            dp_attention_module._LOCAL_ATTN_DP_SIZE = max(1, dp_size // (tp_size // moe_dense_tp_size))
    else:
        dp_attention_module._ATTN_DP_SIZE = 1
        dp_attention_module._LOCAL_ATTN_DP_SIZE = 1

    tp_group = get_tp_group()
    # Trick to solve circular references
    from sglang.srt.layers.attention.nsa.utils import is_nsa_enable_prefill_cp

    use_pynccl = True if is_nsa_enable_prefill_cp() else SYNC_TOKEN_IDS_ACROSS_TP
    dp_attention_module._ATTN_TP_GROUP = GroupCoordinator(
        [
            list(range(head, head + dp_attention_module._ATTN_TP_SIZE))
            for head in range(0, pp_size * tp_size, dp_attention_module._ATTN_TP_SIZE)
        ],
        tp_group.local_rank,
        torch.distributed.get_backend(tp_group.device_group),
        use_pynccl=False,
        use_pymscclpp=False,
        use_custom_allreduce=False,
        use_torch_symm_mem_all_reduce=False,
        use_hpu_communicator=False,
        use_xpu_communicator=False,
        use_npu_communicator=False,
        group_name="attention_tp",
    )

    _DpGatheredBufferWrapper.set_metadata(
        hidden_size=model_config.hidden_size,
        dtype=model_config.dtype,
        device=torch.device(server_args.device),
    )


def _dp_gather_via_all_reduce(
    global_tokens: torch.Tensor,
    local_tokens: torch.Tensor,
    forward_batch: "ForwardBatch",
    is_partial: bool,
):
    local_start_pos, local_num_tokens = get_dp_local_info(forward_batch)

    global_tokens.fill_(0)
    assert local_tokens.is_contiguous()
    assert global_tokens.is_contiguous()

    if local_tokens.shape[0] > 0 and (is_partial or get_attention_tp_rank() == 0):
        assert (
            local_tokens.untyped_storage() is not global_tokens.untyped_storage()
        ), "aliasing between global_tokens and local_tokens not allowed"

        torch.ops.xspeedgate_ops.memcpy_token(
            global_tokens, local_tokens, 0, local_start_pos, local_num_tokens, False
        )

    # Input IDs are in int 32. We should use inplace_all_reduce for local case because of custom all reduce.
    NUM_GPUS_PER_NODE = 8
    if (
        not local_tokens.dtype.is_floating_point
        and get_tensor_model_parallel_world_size() <= NUM_GPUS_PER_NODE
    ):
        from sglang.srt.distributed.parallel_state import inplace_all_reduce
        inplace_all_reduce(global_tokens, group_name=get_tp_group().unique_name)

    else:
        global_tokens[:] = tensor_model_parallel_all_reduce(global_tokens)


def dp_scatter(
    local_tokens: torch.Tensor,  # output
    global_tokens: torch.Tensor,  # input
    forward_batch: "ForwardBatch",
):
    """dp_scatter"""
    # local_num_tokens is not necessarily the same as local_tokens.shape[0],
    # since local_tokens may be padded for cuda graph
    local_start_pos, local_num_tokens = get_dp_local_info(forward_batch)

    local_tokens.fill_(0)
    assert local_tokens.is_contiguous()
    assert global_tokens.is_contiguous()
    if local_tokens.shape[0] > 0:
        assert (
            local_tokens.untyped_storage() is not global_tokens.untyped_storage()
        ), "aliasing between local_tokens and global_tokens not allowed"

        torch.ops.xspeedgate_ops.memcpy_token(
            local_tokens, global_tokens, 0, local_start_pos, local_num_tokens, True
        )


def apply_dp_attention_patch():
    """patch"""
    try:

        dp_attention_module.initialize_dp_attention = initialize_dp_attention
        print("[Patch] sglang.srt.layers.dp_attention.initialize_dp_attention -> \
              sgl_kernel.patch.layers.dp_attention.initialize_dp_attention")

        dp_attention_module._dp_gather_via_all_reduce = _dp_gather_via_all_reduce
        print("[Patch] sglang.srt.layers.dp_attention._dp_gather_via_all_reduce -> \
              sgl_kernel.patch.layers.dp_attention._dp_gather_via_all_reduce")

        dp_attention_module.dp_scatter = dp_scatter
        print("[Patch] sglang.srt.layers.dp_attention.dp_scatter -> \
              sgl_kernel.patch.layers.dp_attention.dp_scatter")

    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_dp_attention_patch()