"""patch for moe.topk"""
import torch
from typing import Optional

from sglang.srt.eplb.expert_location_dispatch import ExpertLocationDispatchInfo


def biased_grouped_topk_gpu(
    hidden_states: torch.Tensor,
    gating_output: torch.Tensor,
    correction_bias: torch.Tensor,
    topk: int,
    renormalize: bool,
    num_expert_group: Optional[int] = None,
    topk_group: Optional[int] = None,
    num_fused_shared_experts: int = 0,
    routed_scaling_factor: Optional[float] = None,
    num_token_non_padded: Optional[torch.Tensor] = None,
    expert_location_dispatch_info: Optional[ExpertLocationDispatchInfo] = None,
    apply_routed_scaling_factor_on_output: Optional[bool] = False,
):
    """biased_grouped_topk_gpu"""
    import kunlun_ops
    topk_weights = torch.empty(hidden_states.shape[0],
                            topk,
                            dtype=torch.float, device=gating_output.device)
    topk_ids = torch.empty(hidden_states.shape[0],
                            topk,
                            dtype=torch.int32, device=gating_output.device)
    block_num = 12
    num_experts = correction_bias.shape[0]
    block_static = torch.empty(
            [block_num, num_experts + 1], dtype=torch.int32, device=gating_output.device)

    kunlun_ops.moe_sigmoid_group_topk_norm(x=gating_output, topk_index=topk_ids,
        norm_score=topk_weights, block_static=block_static,
        bias=correction_bias, scale=2.5, n_group=num_expert_group, topk_group=topk_group)
    return topk_weights, topk_ids

def apply_moe_topk_patch():
    """apply_moe_topk_patch"""
    try:
        import sglang.srt.layers.moe.topk as moe_topk_module

        moe_topk_module.biased_grouped_topk = biased_grouped_topk_gpu
        print("[Patch] sglang.srt.layers.moe.topk.biased_grouped_topk -> \
              sgl_kernel.patch.layers.moe.topk.biased_grouped_topk")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_moe_topk_patch()