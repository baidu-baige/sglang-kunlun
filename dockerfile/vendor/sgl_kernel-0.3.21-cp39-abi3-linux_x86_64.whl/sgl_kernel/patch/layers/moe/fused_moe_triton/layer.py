"""patch for fused_moe_triton.layer"""
from sglang.srt.layers.moe import (
    MoeRunnerConfig,
    get_deepep_mode,
    get_moe_a2a_backend,
)
from sglang.srt.layers.moe.token_dispatcher.standard import StandardDispatcher
from sglang.srt.distributed import get_tp_group

def create_moe_dispatcher(moe_runner_config: MoeRunnerConfig) -> "BaseDispatcher":
    """create_moe_dispatcher"""
    from sglang.srt.batch_overlap.two_batch_overlap import MaybeTboDeepEPDispatcher

    a2a_backend = get_moe_a2a_backend()
    if a2a_backend.is_none():
        return StandardDispatcher(moe_runner_config)
    elif a2a_backend.is_deepep() or a2a_backend.is_mooncake():
        return MaybeTboDeepEPDispatcher(
            group=get_tp_group().device_group,
            router_topk=moe_runner_config.top_k,
            permute_fusion=True,
            num_experts=moe_runner_config.num_experts,
            num_local_experts=moe_runner_config.num_local_experts,
            hidden_size=moe_runner_config.hidden_size,
            params_dtype=moe_runner_config.params_dtype,
            deepep_mode=get_deepep_mode(),
            async_finish=True,
            return_recv_hook=get_deepep_mode().is_normal(),
        )
    elif a2a_backend.is_ascend_fuseep():
        from sglang.srt.layers.moe.token_dispatcher import NpuFuseEPDispatcher

        return NpuFuseEPDispatcher(
            group=get_tp_group().device_group,
            router_topk=moe_runner_config.top_k,
            permute_fusion=True,
            num_experts=moe_runner_config.num_experts,
            num_local_experts=moe_runner_config.num_local_experts,
            hidden_size=moe_runner_config.hidden_size,
            params_dtype=moe_runner_config.params_dtype,
        )
    else:
        raise NotImplementedError(f"Unsupported a2a backend: {a2a_backend}")


def apply_fused_moe_triton_layer_patch():
    """patch"""
    try:
        import sglang.srt.layers.moe.fused_moe_triton.layer as fused_moe_triton_layer_module

        fused_moe_triton_layer_module.create_moe_dispatcher = create_moe_dispatcher
        print("[Patch] sglang.srt.layers.moe.fused_moe_triton.layer.create_moe_dispatcher -> \
              sgl_kernel.patch.layers.moe.fused_moe_triton.layer.create_moe_dispatcher")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_fused_moe_triton_layer_patch()