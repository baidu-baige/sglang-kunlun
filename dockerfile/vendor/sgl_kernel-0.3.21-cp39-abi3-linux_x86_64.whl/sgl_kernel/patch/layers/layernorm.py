'''layernorm patch'''

import torch
from typing import Optional, Tuple, Union


def forward_kunlun(
        self,
        x: torch.Tensor,
        residual: Optional[torch.Tensor] = None,
        post_residual_addition: Optional[torch.Tensor] = None,
    ) -> Union[Tuple[torch.Tensor, torch.Tensor], Tuple[Tuple[torch.Tensor, torch.Tensor], torch.Tensor]]:
        """forward_kunlun"""
        if x.numel() == 0:
            return x
        if self.variance_size_override is not None:
            return self.forward_native(x, residual, post_residual_addition)
        from sglang.srt.batch_invariant_ops import (
            is_batch_invariant_mode_enabled,
            rms_norm_batch_invariant,
        )
        from sglang.srt.server_args import get_global_server_args
        if is_batch_invariant_mode_enabled():
            if (
                residual is not None
                or get_global_server_args().rl_on_policy_target == "fsdp"
            ):
                return self.forward_native(x, residual, post_residual_addition)
            return rms_norm_batch_invariant(
                x,
                self.weight.data,
                self.variance_epsilon,
            )
        import kunlun_ops 
        out = torch.empty_like(x)        
        if residual is not None:
            # TODO: Ideally we want to have (hidden_states+residual)+post_residual_addition.
            # but right now we can only have hidden_states+(residual+post_residual_addition).
            # (hidden_states+residual)+post_residual_addition != hidden_states+(residual+post_residual_addition),
            # we probably need to add another parameter to fused_add_rmsnorm
            if post_residual_addition is not None:
                residual = residual + post_residual_addition
            kunlun_ops.add_rmsnorm(x, residual, self.weight.data, out,
                                   self.variance_epsilon, False, True, None, None, residual, None)
            return out, residual
        else:
            kunlun_ops.rmsnorm(x, self.weight.data, out, 
                               self.variance_epsilon, False, True, None, residual, None)
            return out


def apply_layernorm_patch():
    """patch"""
    try:
        from sglang.srt.layers.layernorm import RMSNorm
        RMSNorm._forward_method = forward_kunlun
        RMSNorm.forward_cuda = forward_kunlun
        print("[Patch] sglang.srt.layers.layernorm -> \
              sgl_kernel.patch.layers.layernorm.forward_cuda")

    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_layernorm_patch()