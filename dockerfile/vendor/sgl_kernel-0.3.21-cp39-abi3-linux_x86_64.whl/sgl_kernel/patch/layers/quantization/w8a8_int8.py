"""patch for w8a8_int8"""

from typing import Any, Optional

import torch
import kunlun_ops
from torch.nn.parameter import Parameter


def linear_process_weights_after_loading(self, layer: torch.nn.Module) -> None:
    """
    Process the weights of a linear layer after loading.
    
    Args:
        layer (torch.nn.Module): The layer to process.
    """
    layer.weight = Parameter(layer.weight.data, requires_grad=False)
    layer.weight_scale = Parameter(
        layer.weight_scale.data * 127, requires_grad=False
    )


def linear_apply(
    self,
    layer: torch.nn.Module,
    x: torch.Tensor,
    bias: Optional[torch.Tensor] = None,
):
    """
    klx_linear_apply
    """
    x_q, x_scale, out = None, None, None
    w_data_shape = layer.weight.data.shape
    w_shape = layer.weight.shape
    if isinstance(x, tuple):
        x_q, x_scale = x
        out = torch.empty((x_q.shape[0], w_shape[0]),
                        dtype=torch.bfloat16,
                        device="cuda")
    else:
        x_shape = x.shape
        x_q = torch.empty(x_shape, dtype=torch.int8, device=x.device)
        x_scale = torch.empty(x_shape[0], dtype=torch.float32, device=x.device)
        out = torch.empty((x_shape[0], w_shape[0]),
                        dtype=x.dtype,
                        device=x.device)
        kunlun_ops.quant2d(x, x_q, x_scale, force_sdnn=True)
    kunlun_ops.matmul(x_q, layer.weight.data, out, bias=bias, x_pc_max=x_scale, w_pc_max=layer.weight_scale.data)
    return out


def moe_process_weights_after_loading(self, layer: torch.nn.Module) -> None:
    """
    Process the weights of a MoE layer after loading.
    
    Args:
        layer (torch.nn.Module): The layer to process.
    """
    layer.w13_weight = Parameter(layer.w13_weight, requires_grad=False)
    layer.w2_weight = Parameter(layer.w2_weight, requires_grad=False)
    layer.w13_weight_scale = Parameter(
        layer.w13_weight_scale.data * 127, requires_grad=False
    )
    layer.w2_weight_scale = Parameter(
        layer.w2_weight_scale.data * 127, requires_grad=False
    )


def moe_apply(
    self,
    layer: torch.nn.Module,
    dispatch_output: "StandardDispatchOutput",
) -> torch.Tensor:
    """
    Apply the MoE operation to the input.
    
    Args:
        layer (torch.nn.Module): The MoE layer.
        dispatch_output (StandardDispatchOutput): The dispatch output.
        
    Returns:
        torch.Tensor: The result of the MoE operation.
    """
    from sglang.srt.layers.moe.token_dispatcher import StandardCombineInput

    x = dispatch_output.hidden_states
    topk_output = dispatch_output.topk_output
    topk_weights, topk_ids, _ = topk_output
    top_k = self.moe_runner_config.top_k
    num_experts = self.moe_runner_config.num_experts
    gateup_output_n = layer.w13_weight.shape[1]
    hidden_size = layer.w2_weight.shape[1]
    num_tokens = x.shape[0]
    device = x.device
    cache: Any = torch.empty(
        num_tokens * top_k * max(gateup_output_n, hidden_size),
        device=device,
        dtype=torch.bfloat16,
    )

    sorted_tokens_num_lod = torch.empty([num_experts + 1], dtype=torch.int32, device=device)
    sorted_tokens_idx = torch.empty(topk_ids.shape, dtype=torch.int32, device=device)
    kunlun_ops.moe_sorted_topk_idx(topk_ids, topk_ids.shape[0], top_k, num_experts,
                                    sorted_tokens_num_lod, sorted_tokens_idx)

    # quant
    x_q = torch.empty_like(x, dtype=torch.int8, device=device)
    x_scale = torch.empty(x.shape[0], dtype=torch.float32, device=device)
    kunlun_ops.quant2d(x, x_q, x_scale, force_sdnn=False)

    # up
    intermediate_cache1 = cache[: num_tokens * top_k * gateup_output_n].view(
        (num_tokens, top_k, gateup_output_n),
    )
    kunlun_ops.moe_fc(x=x_q, weight=layer.w13_weight,
        sorted_tokens_num_lod=sorted_tokens_num_lod,
        sorted_tokens_idx=sorted_tokens_idx, moe_topk=top_k, y=intermediate_cache1, act=None,
        x_perchannel_max=x_scale,
        w_perchannel_max=layer.w13_weight_scale, topk_ids=topk_ids, sort_mode=False)

    # act
    intermediate_cache2 = torch.empty((num_tokens, top_k, gateup_output_n // 2),
                                        dtype=torch.bfloat16, device=device)
    kunlun_ops.swiglu(intermediate_cache1, intermediate_cache2)

    # quant
    intermediate_cache2_q = torch.empty((num_tokens * top_k, gateup_output_n // 2), 
                                        dtype=torch.int8, device=device)
    intermediate_cache2_scale = torch.empty(num_tokens * top_k, dtype=torch.float32, device=device)
    kunlun_ops.quant2d(intermediate_cache2, intermediate_cache2_q, intermediate_cache2_scale, force_sdnn=False)

    # down
    intermediate_cache3 = cache[: num_tokens * top_k * hidden_size].view(
        (num_tokens, top_k, hidden_size),
    )
    kunlun_ops.moe_fc(x=intermediate_cache2_q, weight=layer.w2_weight,
        sorted_tokens_num_lod=sorted_tokens_num_lod,
        sorted_tokens_idx=sorted_tokens_idx, moe_topk=1, y=intermediate_cache3, act=None,
        x_perchannel_max=intermediate_cache2_scale,
        w_perchannel_max=layer.w2_weight_scale, topk_ids=topk_ids,
        topk_w=topk_weights, sort_mode=False)

    # sum
    out = torch.empty((num_tokens, hidden_size), dtype=torch.bfloat16, device=device)
    kunlun_ops.reduce_sum(intermediate_cache3, 1, out)
    return StandardCombineInput(hidden_states=out)


def apply_w8a8int8_patch():
    """patch"""
    try:
        from sglang.srt.layers.quantization.w8a8_int8 import W8A8Int8LinearMethod, W8A8Int8MoEMethod

        W8A8Int8LinearMethod.process_weights_after_loading = linear_process_weights_after_loading
        print("[Patch] sglang.srt.layers.quantization.w8a8_int8.W8A8Int8LinearMethod.process_weights_after_loading -> \
              sgl_kernel.patch.layers.quantization.w8a8_int8.linear_process_weights_after_loading")

        W8A8Int8LinearMethod.apply = linear_apply
        print("[Patch] sglang.srt.layers.quantization.w8a8_int8.W8A8Int8LinearMethod.apply -> \
              sgl_kernel.patch.layers.quantization.w8a8_int8.linear_apply")

        W8A8Int8MoEMethod.process_weights_after_loading = moe_process_weights_after_loading
        print("[Patch] sglang.srt.layers.quantization.w8a8_int8.W8A8Int8MoEMethod.process_weights_after_loading -> \
              sgl_kernel.patch.layers.quantization.w8a8_int8.moe_process_weights_after_loading")

        W8A8Int8MoEMethod.apply = moe_apply
        print("[Patch] sglang.srt.layers.quantization.w8a8_int8.W8A8Int8MoEMethod.apply -> \
              sgl_kernel.patch.layers.quantization.w8a8_int8.moe_apply")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_w8a8int8_patch()