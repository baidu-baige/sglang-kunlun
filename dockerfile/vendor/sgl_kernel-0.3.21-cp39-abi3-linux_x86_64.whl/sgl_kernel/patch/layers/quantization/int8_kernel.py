"""patch for sglang.srt.layers.quantization.int8_kernel
"""
from typing import List, Optional, Tuple

import torch
from kunlun_ops import quant2d


def per_token_quant_int8(x, scale_dtype=torch.float32, cal_sum=False):
    """per_token_quant_int8
    """
    assert not cal_sum, "per_token_quant_int8 cal_sum is not supported for Kunlun."
    assert scale_dtype == torch.float32, "per_token_quant_int8 scale_dtype must be float32 for Kunlun."

    x_shape = x.shape
    x_q = torch.empty(x_shape, dtype=torch.int8, device=x.device)
    scales = torch.empty(x_shape[0], dtype=scale_dtype, device=x.device)
    quant2d(x, x_q, scales, force_sdnn=True)
    return x_q, scales


def per_token_group_quant_int8(
    x: torch.Tensor,
    group_size: int,
    eps: float = 1e-10,
    dtype: torch.dtype = torch.int8,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """per_token_group_quant_int8
    """
    # TODO: implement this
    raise NotImplementedError("per_token_group_quant_int8 is not supported for Kunlun.")


def sglang_per_token_group_quant_int8(
    x: torch.Tensor,
    group_size: int,
    eps: float = 1e-10,
    dtype: torch.dtype = torch.int8,
    enable_v2: Optional[bool] = None,
):
    """sglang_per_token_group_quant_int8
    """
    # TODO: implement this
    raise NotImplementedError("sglang_per_token_group_quant_int8 is not supported for Kunlun.")


def w8a8_block_int8_matmul(
    A: torch.Tensor,
    B: torch.Tensor,
    As: torch.Tensor,
    Bs: torch.Tensor,
    block_size: List[int],
    output_dtype: torch.dtype = torch.float16,
) -> torch.Tensor:
    """w8a8_block_int8_matmul
    """
    # TODO: implement this
    raise NotImplementedError("w8a8_block_int8_matmul is not supported for Kunlun.")

