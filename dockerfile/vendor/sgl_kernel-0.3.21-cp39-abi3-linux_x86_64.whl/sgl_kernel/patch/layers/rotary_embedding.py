'''rotary_embedding'''
import torch
from typing import Optional

from sglang.srt.layers.rotary_embedding import RotaryEmbedding
import xspeedgate_ops

FusedSetKVBufferArg = None


def forward_cuda_kunlun(
    self,
    positions: torch.Tensor,
    query: torch.Tensor,
    key: torch.Tensor,
    offsets: Optional[torch.Tensor] = None,
    fused_set_kv_buffer_arg: Optional[FusedSetKVBufferArg] = None,
):
    """A PyTorch-native implementation of forward()."""
    assert (
        fused_set_kv_buffer_arg is None
    ), "fused_set_kv_buffer_arg is not supported for native implementation"

    if offsets is not None:
        positions = positions + offsets
    positions = positions.flatten()
    num_tokens = positions.shape[0]

    query_shape = query.shape
    query = query.view(num_tokens, -1, self.head_size)

    key_shape = key.shape
    key = key.view(num_tokens, -1, self.head_size)
    
    query, key = torch.ops.xspeedgate_ops.flashinfer_rotary_embedding(
        positions=positions,
        rotary_dim=self.rotary_dim,
        head_size=self.head_size,
        cos_sin_cache=self.cos_sin_cache.to(query.dtype),
        is_neox_style=self.is_neox_style,
        query=query,
        key=key,
        offsets=offsets,
    )
    query = query.reshape(query_shape)
    key = key.reshape(key_shape)
    return query, key

RotaryEmbedding.forward_cuda = forward_cuda_kunlun