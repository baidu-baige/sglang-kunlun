"""patch for linear"""
import torch
from torch.nn.parameter import Parameter
from sglang.srt.layers.linear import ColumnParallelLinear
from sglang.srt.utils import set_weight_attrs


_original_init = ColumnParallelLinear.__init__


def __init_kunlun__(self, *args, **kwargs):
    _original_init(self, *args, **kwargs)
    if self.bias is not None:
        # TODO: fix this. kunlun_ops.matmul requires bias to be float32 now.
        from sglang.srt.layers.quantization.w8a8_int8 import W8A8Int8LinearMethod
        if isinstance(self.quant_method, W8A8Int8LinearMethod):
            params_dtype = torch.float32
        self.bias = Parameter(
            torch.empty(self.output_size_per_partition, dtype=params_dtype)
        )
        set_weight_attrs(
            self.bias,
            {
                "output_dim": 0,
                "weight_loader": self.weight_loader,
            },
        )


def apply_linear_patch():
    """apply_linear_patch"""
    try:
        from sglang.srt.layers.linear import ColumnParallelLinear

        ColumnParallelLinear.__init__ = __init_kunlun__
        print("[Patch] sglang.srt.layers.linear.ColumnParallelLinear.__init__ -> \
            sgl_kernel.patch.layers.linear.__init_kunlun__")

    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")


apply_linear_patch()
