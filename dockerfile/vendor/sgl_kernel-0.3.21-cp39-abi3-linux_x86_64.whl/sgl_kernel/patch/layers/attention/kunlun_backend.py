"""
kunlun attention backend
"""
from dataclasses import dataclass
from typing import Optional

import torch


from sglang.srt.layers.attention.flashattention_backend import FlashAttentionMetadata, FlashAttentionBackend
from sglang.srt.model_executor.forward_batch_info import ForwardBatch, ForwardMode
from sglang.srt.layers.radix_attention import AttentionType
from sglang.srt.speculative.spec_info import SpecInput

from sglang.srt.layers.radix_attention import RadixAttention
from sglang.srt.model_executor.model_runner import ModelRunner

from sglang.srt.utils import (
    log_info_on_rank0,
)

import logging
logger = logging.getLogger(__name__)

from kunlun_ops import prefill_attention, paged_attention


@dataclass
class KunlunAttentionMetadata:
    """Metadata for Kunlun Attention Backend"""
    cache_seqlens_int32_cpu: torch.Tensor = None

    kv_lod_cpu: torch.Tensor = None
    kv_lod_xpu: torch.Tensor = None
    # Cumulative sequence lengths for query
    cu_seqlens_q_cpu: torch.Tensor = None


class KunlunAttentionBackend(FlashAttentionBackend):
    """
    KunlunAttentionBackend
    """
    def __init__(
        self,
        model_runner: ModelRunner,
    ):
        """
        KunlunAttentionBackend
        """
        super().__init__(model_runner)
        assert not self.use_mla, "KunlunAttentionBackend not support mla"
        self.kunlun_attn_metadata = KunlunAttentionMetadata()

    def init_forward_metadata(self, forward_batch: ForwardBatch):
        """init_forward_metadata"""
        super().init_forward_metadata(forward_batch)
        metadata = self.forward_metadata

        self.kunlun_attn_metadata = KunlunAttentionMetadata()
        self.kunlun_attn_metadata.cu_seqlens_q_cpu = metadata.cu_seqlens_q.cpu()
        self.kunlun_attn_metadata.cache_seqlens_int32_cpu = metadata.cache_seqlens_int32.cpu()
        self.kunlun_attn_metadata.kv_lod_cpu = \
            torch.zeros(forward_batch.batch_size + 1, dtype=torch.int32, device="cpu")
        self.kunlun_attn_metadata.kv_lod_cpu[1:] = \
            self.kunlun_attn_metadata.cache_seqlens_int32_cpu.to(torch.int32).cumsum(dim=0)
        self.kunlun_attn_metadata.kv_lod_xpu = \
            self.kunlun_attn_metadata.kv_lod_cpu.to(metadata.cache_seqlens_int32.device)

    def init_forward_metadata_capture_cuda_graph(
            self,
            bs: int,
            num_tokens: int,
            req_pool_indices: torch.Tensor,
            seq_lens: torch.Tensor,
            encoder_lens: Optional[torch.Tensor],
            forward_mode: ForwardMode,
            spec_info: Optional[SpecInput],
        ):
        """init_forward_metadata_capture_cuda_graph"""
        super().init_forward_metadata_capture_cuda_graph(
            bs,
            num_tokens,
            req_pool_indices,
            seq_lens,
            encoder_lens,
            forward_mode,
            spec_info
        )

        metadata = self.forward_metadata
        batch_size = len(metadata.cache_seqlens_int32)
        self.kunlun_attn_metadata = KunlunAttentionMetadata()
        self.kunlun_attn_metadata.cu_seqlens_q_cpu = metadata.cu_seqlens_q.cpu()
        self.kunlun_attn_metadata.cache_seqlens_int32_cpu = metadata.cache_seqlens_int32.cpu()
        self.kunlun_attn_metadata.kv_lod_cpu = torch.zeros(batch_size + 1, dtype=torch.int32, device="cpu")
        self.kunlun_attn_metadata.kv_lod_cpu[1:] = \
            self.kunlun_attn_metadata.cache_seqlens_int32_cpu.to(torch.int32).cumsum(dim=0)
        self.kunlun_attn_metadata.kv_lod_xpu = \
            self.kunlun_attn_metadata.kv_lod_cpu.to(metadata.cache_seqlens_int32.device)

    def forward_extend(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        layer: RadixAttention,
        forward_batch: ForwardBatch,
        save_kv_cache=True,
        # For multi-head latent attention
        q_rope: Optional[torch.Tensor] = None,
        k_rope: Optional[torch.Tensor] = None,
        sinks: Optional[torch.Tensor] = None,
    ):
        """forward_extend"""
        if k is not None:
            assert v is not None
            if save_kv_cache:
                cache_loc = (
                    forward_batch.out_cache_loc
                    if not layer.is_cross_attention
                    else forward_batch.encoder_out_cache_loc
                )
                forward_batch.token_to_kv_pool.set_kv_buffer(
                    layer, cache_loc, k, v, layer.k_scale, layer.v_scale
                )

        # Use precomputed metadata across all layers
        metadata = self.forward_metadata
        # not support mla
        key_cache, value_cache = forward_batch.token_to_kv_pool.get_kv_buffer(
            layer.layer_id
        )
        # Adjust KV cache format to [block_nums, head_nums, block_size, head_dims]
        key_cache = key_cache.view(
            -1, layer.tp_k_head_num, self.page_size, layer.head_dim
        )
        value_cache = value_cache.view(
            -1, layer.tp_v_head_num, self.page_size, layer.head_dim
        )
        q_ro = q.contiguous().view(-1, layer.tp_q_head_num, layer.head_dim)
        if q_ro.dim() == 3:
            q_ro = q_ro.unsqueeze(0)
        result = torch.empty_like(q_ro)

        prefill_attention(
            q=q_ro,
            k=key_cache,
            v=value_cache,
            out=result,
            is_causal=True,
            block_table=metadata.page_table,
            is_prefix_cache=True,
            context_qlen_lod_cpu=self.kunlun_attn_metadata.cu_seqlens_q_cpu,
            context_qlen_lod_xpu=metadata.cu_seqlens_q,
            context_kvlen_lod_cpu=self.kunlun_attn_metadata.kv_lod_cpu,
            context_kvlen_lod_xpu=self.kunlun_attn_metadata.kv_lod_xpu,
            alibi_slopes=None,
            softmax_lse=None,
        )

        return result.view(-1, layer.tp_q_head_num * layer.v_head_dim)
    
    def forward_decode(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        layer: RadixAttention,
        forward_batch: ForwardBatch,
        save_kv_cache=True,
        # For multi-head latent attention
        q_rope: Optional[torch.Tensor] = None,
        k_rope: Optional[torch.Tensor] = None,
        sinks: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """forward_decode"""
        if k is not None:
            assert v is not None
            if save_kv_cache:
                cache_loc = (
                    forward_batch.out_cache_loc
                    if not layer.is_cross_attention
                    else forward_batch.encoder_out_cache_loc
                )
                forward_batch.token_to_kv_pool.set_kv_buffer(
                    layer, cache_loc, k, v, layer.k_scale, layer.v_scale
                )
        metadata = self.forward_metadata
        # not support mla
        key_cache, value_cache = forward_batch.token_to_kv_pool.get_kv_buffer(
            layer.layer_id
        )
        # Adjust KV cache format to [block_nums, head_nums, block_size, head_dims]
        key_cache = key_cache.view(
            -1, layer.tp_k_head_num, self.page_size, layer.head_dim
        )
        value_cache = value_cache.view(
            -1, layer.tp_v_head_num, self.page_size, layer.head_dim
        )
        q_reshaped = q.contiguous().view(
            -1, layer.tp_q_head_num, layer.head_dim
        )

        if q_reshaped.dim() == 3:
            q_reshaped = q_reshaped.unsqueeze(1)
        result = torch.empty_like(q_reshaped)
        paged_attention(
            x=q_reshaped,
            k_cache=key_cache,
            v_cache=value_cache,
            block_tables=metadata.page_table,
            context_lens_cpu=self.kunlun_attn_metadata.cache_seqlens_int32_cpu,
            context_lens_xpu=metadata.cache_seqlens_int32,
            is_context=False,
            is_causal=True,
            out=result,
            vo_head_dim=-1,
        )
        result = result.to(q_reshaped.dtype).view(-1, layer.tp_q_head_num * layer.v_head_dim)
        return result
