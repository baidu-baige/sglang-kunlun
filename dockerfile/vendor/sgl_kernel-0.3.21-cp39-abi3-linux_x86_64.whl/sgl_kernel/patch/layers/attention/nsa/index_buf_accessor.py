""" triton """
import torch
import kunlun_ops
import xspeedgate_ops

def _get_k_triton(
    buf: torch.Tensor,
    page_indices: torch.Tensor,
    seq_len: int,
    page_size: int,
    index_head_dim: int,
):
    """
    Gather K (key) data from paged buffer using Triton.

    :param buf: (num_pages, page_size * 128 + page_size * 4), uint8
    :param page_indices: (num_pages,), int32/int64
    :param seq_len: int, number of tokens to gather
    :param page_size: int, typically 64
    :param index_head_dim: int, typically 128
    :return: (seq_len, index_head_dim), uint8
    """
    num_pages, buf_numel_per_page = buf.shape

    return torch.ops.xspeedgate_ops.get_k_kernel(
            buf.contiguous(), page_indices.contiguous(), seq_len, page_size, buf_numel_per_page, index_head_dim)

def _get_s_triton(
    buf: torch.Tensor,
    page_indices: torch.Tensor,
    seq_len: int,
    page_size: int,
    index_head_dim: int,
):
    """
    Gather S (scale) data from paged buffer using Triton.

    :param buf: (num_pages, page_size * 128 + page_size * 4), uint8
    :param page_indices: (num_pages,), int32/int64
    :param seq_len: int, number of tokens to gather
    :param page_size: int, typically 64
    :param index_head_dim: int, typically 128
    :return: (seq_len, 4), uint8 (representing fp32 scale)
    """
    num_pages, buf_numel_per_page = buf.shape
    s_offset_in_page = page_size * index_head_dim  # Scales start after K data

    return torch.ops.xspeedgate_ops.get_s_kernel(
            buf.contiguous(), page_indices.contiguous(), seq_len, page_size, buf_numel_per_page, s_offset_in_page)


@classmethod
def set_k_and_s_triton(cls, pool, buf, loc, index_k, index_k_scale):
    """ set_k_and_s_triton """
    kunlun_ops.set_k_and_s_triton(
        buf=buf.contiguous(),
        loc=loc.to(torch.int64).contiguous(),
        index_k=index_k.contiguous(),
        index_k_scale=index_k_scale.contiguous(),
        page_size=pool.page_size,
    )


@classmethod
def kunlun_execute(cls, *args, **kwargs):
    """ kunlun_execute """
    return cls.torch_fast(*args, **kwargs)


def apply_index_buf_accessor_patch():
    """patch"""
    try:
        from sglang.srt.layers.attention.nsa.index_buf_accessor import GetK, GetS, SetKAndS
        import sglang.srt.layers.attention.nsa.index_buf_accessor as index_buf_accessor

        SetKAndS.triton = set_k_and_s_triton
        print("[Patch] sglang.srt.layers.attention.nsa.index_buf_accessor.SetKAndS.triton -> \
              sgl_kernel.patch.layers.attention.nsa.index_buf_accessor.triton")
        
        #GetK.execute = kunlun_execute
        index_buf_accessor._get_k_triton = _get_k_triton
        print("[Patch] sglang.srt.layers.attention.nsa.index_buf_accessor._get_k_triton -> \
              sgl_kernel.patch.layers.attention.nsa.index_buf_accessor._get_k_triton")
        
        #GetS.execute = kunlun_execute
        index_buf_accessor._get_s_triton = _get_s_triton
        print("[Patch] sglang.srt.layers.attention.nsa.index_buf_accessor._get_s_triton -> \
              sgl_kernel.patch.layers.attention.nsa.index_buf_accessor._get_s_triton")

    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")


apply_index_buf_accessor_patch()
