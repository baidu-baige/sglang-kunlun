""" triton_kernel """
from typing import Optional, Tuple
import torch
from kunlun_ops import quant2d


def act_quant_kunlun(
    x: torch.Tensor, block_size: int = 128, scale_fmt: Optional[str] = None
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Quantizes the input tensor `x` using block-wise quantization with Triton.

    Args:
        x (torch.Tensor): The input tensor to be quantized. 
        Must be contiguous and its last dimension size must be divisible by `block_size`.
        block_size (int, optional): The size of the blocks to be used for quantization. Default is 128.
        scale_fmt (Optional[str], optional): The format of the scale. Default is None.
    Returns:
        Tuple[torch.Tensor, torch.Tensor]: A tuple containing:
            - The quantized tensor with dtype `torch.float8_e4m3fn`.
            - A tensor of scaling factors with dtype `torch.float32`.
    """
    assert x.is_contiguous(), "Input tensor must be contiguous"
    assert (
        x.size(-1) % block_size == 0
    ), f"Last dimension size must be divisible by block_size (block_size={block_size})"

    assert x.dtype in (torch.bfloat16, torch.float16, torch.float32)

    # 按 block_size 做 per-block absmax
    x_padded = x.view(-1, block_size)                      # [num_block, block_size]
    scale = x_padded.abs().amax(dim=1, keepdim=True)      # [num_block, 1]
    # 避免除 0
    scale = torch.clamp(scale, min=1e-10)
    x_scaled = x_padded / scale                            # [-1, 1]
    # 缩放到 FP8 E4M3 范围 [-448, 448]
    x_scaled = x_scaled * 448.0
    # cast → float8_e4m3fn （PyTorch 2.1+ 支持）
    fp8_tensor = x_scaled.to(torch.int8)
    # reshape 回原形状
    fp8_tensor = fp8_tensor.view(x.shape)
    # scale 也 reshape 成 [seq_len, hidden // block_size]
    scale = scale.view(x.shape[0], -1).to(torch.float32)
    return fp8_tensor, scale


def apply_triton_kernel_patch():
    """patch"""
    try:
        import sglang.srt.layers.attention.nsa.triton_kernel as tk

        tk.act_quant = act_quant_kunlun
        print("[Patch] sglang.srt.layers.attention.nsa.triton_kernel.act_quant -> \
              sgl_kernel.patch.layers.attention.nsa.triton_kernel.act_quant_kunlun")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_triton_kernel_patch()
