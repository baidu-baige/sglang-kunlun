"""patch for attention_registry"""
from sglang.srt.layers.attention.attention_registry import register_attention_backend


@register_attention_backend("kunlun")
def create_kunlun_attention_backend(runner):
    "create_kunlun_attention_backend"
    from sgl_kernel.patch.layers.attention.kunlun_backend import KunlunAttentionBackend

    return KunlunAttentionBackend(runner)


def apply_backend_patch():
    """
    apply_backend_patch
    """
    try:
        import sglang.srt.layers.attention.attention_registry as attention_registry

        attention_registry.create_kunlun_attention_backend = create_kunlun_attention_backend
        print("[Patch] attention_registry.create_kunlun_attention_backend patched successfully.")
    except ImportError as e:
        print(f"[Patch Error] Failed to patch attention_registry.create_kunlun_attention_backend: {e}")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")


apply_backend_patch()
