""" deepseek_v2 """
import torch
from sglang.srt.models.deepseek_v2 import DeepseekV2AttentionMLA

def _concat_and_cast_mha_k(self, k_nope, k_pe, forward_batch):
    """ _concat_and_cast_mha_k """
    # Temporary for DeepSeek V3/R1 only, but can generalize if needed
    k_shape = (k_nope.shape[0], self.num_local_heads, self.qk_head_dim)
    k = k_nope.new_empty(*k_shape)
    torch.ops.xspeedgate_ops.concat_and_cast_mha_k(k, k_nope, k_pe)
    return k
DeepseekV2AttentionMLA._concat_and_cast_mha_k = _concat_and_cast_mha_k
print("[Patch] sglang.srt.models.deepseek_v2.DeepseekV2AttentionMLA._concat_and_cast_mha_k -> \
            sgl_kernel.patch.models.deepseek_v2._concat_and_cast_mha_k")
