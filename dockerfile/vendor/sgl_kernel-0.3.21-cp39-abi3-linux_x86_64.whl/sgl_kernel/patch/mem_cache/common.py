"""common"""

import torch
from sglang.srt.mem_cache.common import get_last_loc_torch
import xspeedgate_ops


def get_last_loc_kunlun(
    req_to_token: torch.Tensor,
    req_pool_indices_tensor: torch.Tensor,
    prefix_lens_tensor: torch.Tensor,
) -> torch.Tensor:
    '''get_last_loc_kunlun'''
    # torch native: sglang.srt.mem_cache.common.get_last_loc_torch
    return torch.ops.xspeedgate_ops.get_last_loc(req_to_token.contiguous(),
        req_pool_indices_tensor.contiguous(), prefix_lens_tensor.contiguous())


def write_cache_indices_kunlun(
    out_cache_loc: torch.Tensor,
    req_pool_indices_tensor: torch.Tensor,
    req_pool_indices_cpu: torch.Tensor,
    prefix_lens_tensor: torch.Tensor,
    prefix_lens_cpu: torch.Tensor,
    seq_lens_tensor: torch.Tensor,
    seq_lens_cpu: torch.Tensor,
    extend_lens_tensor: torch.Tensor,
    extend_lens_cpu: torch.Tensor,
    prefix_tensors: list[torch.Tensor],
    req_to_token_pool: 'ReqToTokenPool',
):
    '''write_cache_indices_kunlun'''
    prefix_pointers = torch.tensor(
        [t.data_ptr() for t in prefix_tensors],
        device=req_to_token_pool.device,
        dtype=torch.uint64,
    )
    out_cache_loc = out_cache_loc.to(torch.int64)
    torch.ops.xspeedgate_ops.write_req_to_token_pool(
        req_to_token_pool.req_to_token.contiguous(),
        req_pool_indices_tensor.to(torch.int32).contiguous(),
        prefix_pointers,
        prefix_lens_tensor.contiguous(),
        seq_lens_tensor.contiguous(),
        extend_lens_tensor.contiguous(),
        out_cache_loc.contiguous(),
    )


def mem_cache_common_patch():
    """
    mem_cache_common_patch
    """
    try:
        import sglang.srt.mem_cache.common as mem_cache_common_module

        mem_cache_common_module.get_last_loc = get_last_loc_kunlun
        mem_cache_common_module.write_cache_indices = write_cache_indices_kunlun
        print("[Patch] get_last_loc patched successfully.")
    except ImportError as e:
        print(f"[Patch Error] Failed to patch get_last_loc: {e}")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

mem_cache_common_patch()
