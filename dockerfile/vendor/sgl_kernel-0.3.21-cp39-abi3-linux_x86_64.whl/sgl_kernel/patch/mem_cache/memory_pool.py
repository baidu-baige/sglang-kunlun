"""patch for memory_pool
"""
import torch
import numpy as np
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple, Union

from contextlib import nullcontext
from sglang.srt.constants import GPU_MEMORY_TYPE_KV_CACHE
from sglang.srt.layers.radix_attention import RadixAttention

from kunlun_ops import set_mla_kv_buffer_triton, reshape_and_cache


def _create_buffers(self):
    """
    _create_buffers
    """
    with self.memory_saver_adapter.region(GPU_MEMORY_TYPE_KV_CACHE):
        with (
            torch.cuda.use_mem_pool(self.custom_mem_pool)
            if self.enable_custom_mem_pool
            else nullcontext()
        ):
            # [size, head_num, head_dim] for each layer
            # The padded slot 0 is used for writing dummy outputs from padded tokens.
            self.k_buffer = [
                torch.zeros(
                    (self.size + self.page_size, self.head_num, self.head_dim),
                    dtype=self.store_dtype,
                    device=self.device,
                )
                for _ in range(self.layer_num)
            ]
            self.v_buffer = [
                torch.zeros(
                    (self.size + self.page_size, self.head_num, self.v_head_dim),
                    dtype=self.store_dtype,
                    device=self.device,
                )
                for _ in range(self.layer_num)
            ]
    # Not support torch.cat when dtype is torch.uint64 now
    self.data_ptrs = torch.tensor(
        [x.data_ptr() for x in self.k_buffer] + [x.data_ptr() for x in self.v_buffer],
        dtype=torch.uint64,
        device=self.device,
    )
    self.data_strides = torch.tensor(
        [
            np.prod(x.shape[1:]) * x.dtype.itemsize
            for x in self.k_buffer + self.v_buffer
        ],
        device=self.device,
    )


def set_mla_kv_buffer(self, layer, loc, cache_k_nope, cache_k_rope):
    """
    set_mla_kv_buffer
    """
    layer_id = layer.layer_id
    if cache_k_nope.dtype != self.dtype:
        cache_k_nope = cache_k_nope.to(self.dtype)
        cache_k_rope = cache_k_rope.to(self.dtype)
    if self.store_dtype != self.dtype:
        cache_k_nope = cache_k_nope.view(self.store_dtype)
        cache_k_rope = cache_k_rope.view(self.store_dtype)
    
    set_mla_kv_buffer_triton(
        self.kv_buffer[layer_id],
        loc.contiguous(),
        cache_k_nope.contiguous().view(cache_k_nope.shape[0], cache_k_nope.shape[-1]),
        cache_k_rope.contiguous().view(cache_k_rope.shape[0], cache_k_rope.shape[-1])
    )


def get_mla_kv_buffer_kunlun(
    self,
    layer: RadixAttention,
    loc: torch.Tensor,
    dst_dtype: Optional[torch.dtype] = None,
):
    """get_mla_kv_buffer_kunlun
    """
    # get k nope and k rope from the kv buffer, and optionally cast them to dst_dtype.
    layer_id = layer.layer_id
    kv_buffer = self.get_key_buffer(layer_id)
    dst_dtype = dst_dtype or self.dtype
    cache_k_nope = torch.empty(
        (loc.shape[0], 1, self.kv_lora_rank),
        dtype=dst_dtype,
        device=kv_buffer.device,
    )
    cache_k_rope = torch.empty(
        (loc.shape[0], 1, self.qk_rope_head_dim),
        dtype=dst_dtype,
        device=kv_buffer.device,
    )
    # for kunlun
    torch.ops.xspeedgate_ops.get_mla_kv_buffer(
        kv_buffer.contiguous(),
        loc.contiguous(),
        cache_k_nope.contiguous(),
        cache_k_rope.contiguous(),
    )
    return cache_k_nope, cache_k_rope


def set_kv_buffer_mha_kunlun(
    self,
    layer: RadixAttention,
    loc: torch.Tensor,
    cache_k: torch.Tensor,
    cache_v: torch.Tensor,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
    layer_id_override: Optional[int] = None,
):
    '''set_kv_buffer_mha_kunlun'''
    if layer_id_override is not None:
        layer_id = layer_id_override
    else:
        layer_id = layer.layer_id
    if cache_k.dtype != self.dtype:
        if k_scale is not None:
            cache_k.div_(k_scale)
        if v_scale is not None:
            cache_v.div_(v_scale)

        if not self.enable_int8_kv_cache:
            cache_k = cache_k.to(self.dtype)
            cache_v = cache_v.to(self.dtype)

    if self.store_dtype != self.dtype:
        cache_k = cache_k.view(self.store_dtype)
        cache_v = cache_v.view(self.store_dtype)

    if cache_k.dim() == 3 and cache_k.shape[0] == loc.numel():
        k_bhd = cache_k.contiguous()
        v_bhd = cache_v.contiguous()
    elif cache_k.dim() == 3 and cache_k.shape[1] == loc.numel():
        # [H, B, D] -> [B, H, D]
        k_bhd = cache_k.permute(1, 0, 2).contiguous()
        v_bhd = cache_v.permute(1, 0, 2).contiguous()
    else:
        raise RuntimeError(
            f"Unexpected K/V shape {tuple(cache_k.shape)} vs loc {tuple(loc.shape)}"
        )

    k4 = self.k_buffer[layer_id - self.start_layer]
    v4 = self.v_buffer[layer_id - self.start_layer]

    reshape_and_cache(k_bhd, v_bhd, k4, v4, loc.to(torch.int32), None, None, 0)


def apply_mla_patch():
    """
    apply_mla_patch
    """
    try:
        from sglang.srt.mem_cache.memory_pool import NSATokenToKVPool, MLATokenToKVPool, MHATokenToKVPool

        MHATokenToKVPool._create_buffers = _create_buffers
        MHATokenToKVPool.set_kv_buffer = set_kv_buffer_mha_kunlun
        MLATokenToKVPool.set_mla_kv_buffer = set_mla_kv_buffer
        MLATokenToKVPool.get_mla_kv_buffer = get_mla_kv_buffer_kunlun
        NSATokenToKVPool.index_k_with_scale_buffer_dtype = torch.int8
        print("[Patch] MLATokenToKVPool.set_mla_kv_buffer patched successfully.")
        print("[Patch] MLATokenToKVPool.get_mla_kv_buffer patched successfully.")
    except ImportError as e:
        print(f"[Patch Error] Failed to patch MLATokenToKVPool.set_mla_kv_buffer: {e}")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_mla_patch()
