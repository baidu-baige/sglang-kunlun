'''allocator'''
import torch
from sglang.srt.mem_cache.allocator import PagedTokenToKVPoolAllocator
from sglang.srt.utils import get_num_new_pages, next_power_of_2

from sgl_kernel.patch.environ import envs
import xspeedgate_ops


def alloc_extend_baseline(pre_lens, seq_lens, last_loc, free_page, page_size):
    """
    CPU baseline实现，用于验证Triton kernel的正确性

    参数:
        pre_lens: [bs], 每个序列之前的长度
        seq_lens: [bs], 每个序列当前的总长度
        last_loc: [bs], 每个序列最后一个token的位置
        free_page: [max_free_pages], 可用的空闲页列表
        page_size: 每页的大小

    返回:
        out_indices: 所有扩展token的物理位置索引
        total_new_pages: 总共需要的新页数
        total_extend: 总共的扩展token数
    """
    bs = pre_lens.shape[0]
    extend_lens = seq_lens - pre_lens
    total_extend = extend_lens.sum()
    out_indices = [-1] * total_extend

    # 计算每个序列需要的新页数
    num_pages_after = (seq_lens + page_size - 1) // page_size
    num_pages_before = (pre_lens + page_size - 1) // page_size
    num_new_pages = num_pages_after - num_pages_before
    total_new_pages = num_new_pages.sum()

    # 跟踪已使用的空闲页
    used_free_pages = 0

    output_offset = 0
    last_loc = last_loc.cpu()
    free_page = free_page.cpu()
    for i in range(bs):
        extend_len = extend_lens[i].item()
        if extend_len == 0:
            continue

        pre_len = pre_lens[i].item()
        seq_len = seq_lens[i].item()

        # Part 1: 填充旧的部分页
        part1_end = min(seq_len, ((pre_len + page_size - 1) // page_size) * page_size)
        num_part1 = part1_end - pre_len

        for j in range(num_part1):
            out_indices[output_offset + j] = last_loc[i] + 1 + j

        output_offset += num_part1

        if pre_len + num_part1 < seq_len:
            # Part 2: 填充新的完整页
            part2_start = part1_end
            part2_end = (seq_len // page_size) * page_size
            num_part2 = part2_end - part2_start

            for j in range(num_part2):
                page_idx = used_free_pages + (j // page_size)
                in_page_offset = j % page_size
                out_indices[output_offset + j] = free_page[page_idx] * page_size + in_page_offset

            used_free_pages += num_part2 // page_size
            output_offset += num_part2

            if part2_end < seq_len:
                # Part 3: 填充新的部分页
                num_part3 = seq_len - part2_end
                page_idx = used_free_pages

                for j in range(num_part3):
                    out_indices[output_offset + j] = free_page[page_idx] * page_size + j

                used_free_pages += 1
                output_offset += num_part3

    out_indices = torch.tensor(out_indices, dtype=torch.int32)
    return out_indices, total_new_pages, total_extend


def alloc_extend_torch_native(
    page_size: int,
    free_pages: torch.Tensor,
    prefix_lens: torch.Tensor,
    seq_lens: torch.Tensor,
    last_loc: torch.Tensor,
    extend_num_tokens: int,
):
    '''alloc_extend_torch_native'''
    out_indices, total_new_pages, total_extend = alloc_extend_baseline(
        prefix_lens,
        seq_lens,
        last_loc,
        free_pages,
        page_size,
    )
    high_bits = total_new_pages.to(torch.int64)
    low_bits = total_extend.to(torch.int64)
    low_bits = low_bits & 0xFFFFFFFF
    origin_num_new_pages =  (high_bits << 32) | low_bits

    return out_indices, origin_num_new_pages


def alloc_extend_kunlun(
    page_size: int,
    free_pages: torch.Tensor,
    prefix_lens: torch.Tensor,
    seq_lens: torch.Tensor,
    last_loc: torch.Tensor,
    extend_num_tokens: int,
):
    '''alloc_extend_kunlun'''
    # xdnn
    from torch_xmlir.nn.alloc_extend import Alloc_extend
    alloc_extend_kunlun = Alloc_extend()
    out_indices, origin_num_new_pages = alloc_extend_kunlun(
        prefix_lens,
        seq_lens,
        last_loc,
        free_pages,
        page_size,
        extend_num_tokens
    )
    out_indices = out_indices.to(torch.int32)
    return out_indices, origin_num_new_pages

def alloc_extend_kernel(
    page_size: int,
    free_pages: torch.Tensor,
    prefix_lens: torch.Tensor,
    seq_lens: torch.Tensor,
    last_loc: torch.Tensor,
    extend_num_tokens: int,
):
    '''alloc_extend_kernel'''
    bs = prefix_lens.shape[0]
    out_indices = torch.zeros(extend_num_tokens, dtype=torch.int64, device="cuda")
    ret_value = torch.zeros(1, dtype=torch.int64, device="cuda")
    
    torch.ops.xspeedgate_ops.alloc_extend(
        prefix_lens,
        seq_lens,
        last_loc.contiguous(),
        free_pages,
        bs,
        page_size,
        extend_num_tokens,
        out_indices.contiguous(),
        ret_value,
    )
    return out_indices, ret_value


alloc_extend_func = alloc_extend_kernel
if envs.USE_FAST_ALLOC_EXTEND_KUNLUN.get():
    alloc_extend_func = alloc_extend_kunlun



def alloc_extend(
    self: "PagedTokenToKVPoolAllocator",
    prefix_lens: torch.Tensor,
    prefix_lens_cpu: torch.Tensor,
    seq_lens: torch.Tensor,
    seq_lens_cpu: torch.Tensor,
    last_loc: torch.Tensor,
    extend_num_tokens: int,
):
    """ alloc_extend """
    if self.debug_mode:
        assert torch.all(
            (last_loc + 1) % self.page_size == prefix_lens % self.page_size
        )

    bs = len(prefix_lens)
    if self.need_sort and extend_num_tokens // self.page_size + bs + 1 > len(
        self.free_pages
    ):
        self.merge_and_sort_free()

    # out_indices = torch.empty(
    #     (extend_num_tokens,), dtype=torch.int64, device=self.device
    # )
    
    out_indices, origin_num_new_pages = alloc_extend_func(
        self.page_size,
        self.free_pages,
        prefix_lens,
        seq_lens,
        last_loc,
        extend_num_tokens
    )

    if self.debug_mode:
        assert len(torch.unique(out_indices)) == len(out_indices)

    merged_value = origin_num_new_pages.item()
    num_new_pages = merged_value >> 32
    if num_new_pages > len(self.free_pages):
        return None

    self.free_pages = self.free_pages[num_new_pages:]
    return out_indices


def paged_alloc_decode_func(
    seq_lens, 
    last_loc,
    free_pages,
    page_size,
    bs,
    device
):
    '''paged_alloc_decode_func'''
    out_indices = torch.empty((bs,), dtype=torch.int64, device=device)
    pre_lens = seq_lens - 1
    num_pages_after = (seq_lens + page_size - 1) // page_size
    num_pages_before = (pre_lens + page_size - 1) // page_size
    num_new_pages = num_pages_after - num_pages_before

    # 创建掩码标识需要新页的序列
    mask = num_new_pages > 0
    sum_new_pages = mask.sum()

    # 初始化所有位置为last_loc + 1
    out_indices = last_loc + 1

    # 处理需要分配新页的情况
    if sum_new_pages > 0:
        # 获取需要分配的页号并计算物理地址
        used_pages = free_pages[:sum_new_pages]
        page_starts = used_pages * page_size

        # 使用向量化操作更新需要新页的位置
        out_indices[mask] = page_starts
    return out_indices


def alloc_decode(
    self,
    seq_lens: torch.Tensor,
    seq_lens_cpu: torch.Tensor,
    last_loc: torch.Tensor,
):
    '''alloc_decode'''
    if self.debug_mode:
        assert torch.all(
            (last_loc + 2) % self.page_size == seq_lens % self.page_size
        )

    bs = len(seq_lens)
    if self.need_sort and bs > len(self.free_pages):
        self.merge_and_sort_free()

    if 0:
        out_indices = paged_alloc_decode_func(
            seq_lens,
            last_loc,
            self.free_pages,
            self.page_size,
            bs,
            self.device
        )
    else:
        out_indices = torch.empty((bs,), dtype=torch.int64, device=self.device)
        torch.ops.xspeedgate_ops.alloc_decode_kernel(
            seq_lens,
            last_loc.contiguous(),
            self.free_pages,
            out_indices.contiguous(),
            next_power_of_2(bs),
            self.page_size,
            bs,
        )

    if self.debug_mode:
        assert len(torch.unique(out_indices)) == len(out_indices)

    num_new_pages = get_num_new_pages(
        seq_lens=seq_lens_cpu,
        page_size=self.page_size,
        decode=True,
    )
    if num_new_pages > len(self.free_pages):
        return None

    self.free_pages = self.free_pages[num_new_pages:]
    return out_indices


def apply_memcache_allocator_patch():
    """patch"""
    try:
        from sglang.srt.mem_cache.allocator import PagedTokenToKVPoolAllocator

        PagedTokenToKVPoolAllocator.alloc_extend = alloc_extend
        PagedTokenToKVPoolAllocator.alloc_decode = alloc_decode
        print("[Patch] sglang.srt.mem_cache.allocator.PagedTokenToKVPoolAllocator -> \
            sgl_kernel.patch.mem_cache.allocator.alloc_extend")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_memcache_allocator_patch()
