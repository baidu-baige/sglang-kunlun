"""utils"""

from kunlun_ops import set_mla_kv_buffer_triton


def apply_memcache_utils_patch():
    """patch"""
    try:
        import sglang.srt.mem_cache.utils as mem_utils_module

        mem_utils_module.set_mla_kv_buffer_triton = set_mla_kv_buffer_triton
        print("[Patch] sglang.srt.mem_cache.utils.set_mla_kv_buffer_triton -> \
            kunlun_ops.set_mla_kv_buffer_triton")
       
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_memcache_utils_patch()