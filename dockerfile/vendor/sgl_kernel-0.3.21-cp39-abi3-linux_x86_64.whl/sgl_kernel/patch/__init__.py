"""init patch"""
import sys
import importlib
import warnings
import builtins


OLD_IMPORT_HOOK = builtins.__import__
def _custom_import(module_name, globals=None, locals=None, fromlist=(), level=0):
    try:
        module_mappings = {
            "sglang.srt.layers.attention.nsa_backend": "sgl_kernel.patch.layers.attention.nsa_backend",
            "sglang.srt.layers.quantization.int8_kernel": "sgl_kernel.patch.layers.quantization.int8_kernel",
            "sglang.srt.layers.moe.ep_moe.layer": "sgl_kernel.patch.layers.moe.ep_moe.layer",
            "sglang.srt.layers.moe.token_dispatcher.deepep": "sgl_kernel.patch.layers.moe.token_dispatcher.deepep"
        }

        if module_name in module_mappings:
            if module_name in sys.modules:
                return sys.modules[module_name]
            target_module = module_mappings[module_name]
            module = importlib.import_module(target_module)
            sys.modules[module_name] = module
            sys.modules[target_module] = module
            print(f"[Patch] module {module_name} -> {target_module}.")
    except Exception as e:
        warnings.warn(f"Import hook failed for {module_name}: {str(e)}", UserWarning)

    return OLD_IMPORT_HOOK(
        module_name,
        globals=globals,
        locals=locals,
        fromlist=fromlist,
        level=level
    )

def import_hook():
    """import_hook"""
    builtins.__import__ = _custom_import

# def apply_patch():
#     """Apply all patches by dynamically importing all modules in sgl_kernel.patch"""
#     import pkgutil

#     def import_submodules(package_name, recursive=True):
#         package = importlib.import_module(package_name)

#         for loader, module_name, is_pkg in pkgutil.walk_packages(
#             package.__path__, 
#             package.__name__ + '.'
#         ):
#             try:
#                 importlib.import_module(module_name)
#             except Exception as e:
#                 print(f"Warning: Failed to import {module_name}: {e}")

#     import_submodules('sgl_kernel.patch')

def apply_patch():
    """apply patch"""
    import sgl_kernel.patch.server_args
    import sgl_kernel.patch.layers.attention.nsa.nsa_indexer
    import sgl_kernel.patch.distributed.parallel_state
    import sgl_kernel.patch.layers.linear
    import sgl_kernel.patch.layers.dp_attention
    import sgl_kernel.patch.layers.attention.nsa_backend
    import sgl_kernel.patch.layers.attention.nsa.index_buf_accessor
    import sgl_kernel.patch.layers.attention.nsa.triton_kernel
    import sgl_kernel.patch.layers.attention.attention_registry
    import sgl_kernel.patch.layers.moe.fused_moe_triton.layer
    import sgl_kernel.patch.layers.moe.topk
    import sgl_kernel.patch.layers.quantization.w8a8_int8
    import sgl_kernel.patch.mem_cache.allocator
    import sgl_kernel.patch.mem_cache.utils
    import sgl_kernel.patch.mem_cache.memory_pool
    import sgl_kernel.patch.model_executor.forward_batch_info
    import sgl_kernel.patch.speculative.eagle_worker
    import sgl_kernel.patch.utils.common
    import sgl_kernel.patch.models
    import sgl_kernel.patch.constrained.xgrammar_backend

import_hook()
# to make patch available 
apply_patch()


