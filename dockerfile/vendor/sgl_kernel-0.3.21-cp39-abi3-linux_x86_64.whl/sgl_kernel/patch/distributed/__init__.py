"""patch for parallel_state
"""