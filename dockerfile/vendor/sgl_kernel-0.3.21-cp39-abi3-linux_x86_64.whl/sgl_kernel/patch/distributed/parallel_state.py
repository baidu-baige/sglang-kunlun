"""parallel_state
"""
from typing import List, Optional

from sglang.srt.distributed.parallel_state import (
    _ENABLE_CUSTOM_ALL_REDUCE, 
    _ENABLE_MSCCLPP_ALL_REDUCE, 
    _ENABLE_TORCH_SYMM_MEM_ALL_REDUCE,
    GroupCoordinator
)


def kunlun_init_model_parallel_group(
    group_ranks: List[List[int]],
    local_rank: int,
    backend: str,
    use_custom_allreduce: Optional[bool] = None,
    use_message_queue_broadcaster: bool = False,
    group_name: Optional[str] = None,
    use_mscclpp_allreduce: Optional[bool] = None,
    pynccl_use_current_stream: bool = True,
    use_torch_symm_mem_allreduce: Optional[bool] = None,
) -> GroupCoordinator:
    """patch for sglang.srt.distributed.parallel_state.init_model_parallel_group
    """
    if use_custom_allreduce is None:
        use_custom_allreduce = _ENABLE_CUSTOM_ALL_REDUCE
    if use_mscclpp_allreduce is None:
        use_mscclpp_allreduce = _ENABLE_MSCCLPP_ALL_REDUCE
    if use_torch_symm_mem_allreduce is None:
        use_torch_symm_mem_allreduce = _ENABLE_TORCH_SYMM_MEM_ALL_REDUCE
    return GroupCoordinator(
        group_ranks=group_ranks,
        local_rank=local_rank,
        torch_distributed_backend=backend,
        use_pynccl=False,
        use_pymscclpp=use_mscclpp_allreduce,
        use_custom_allreduce=use_custom_allreduce,
        use_torch_symm_mem_all_reduce=use_torch_symm_mem_allreduce,
        use_hpu_communicator=True,
        use_xpu_communicator=True,
        use_npu_communicator=True,
        use_message_queue_broadcaster=use_message_queue_broadcaster,
        group_name=group_name,
        pynccl_use_current_stream=pynccl_use_current_stream,
    )


def apply_parallel_state_patch():
    """patch"""
    try:
        import sglang.srt.distributed.parallel_state as parallel_state_module

        parallel_state_module.init_model_parallel_group = kunlun_init_model_parallel_group
        print("[Patch] sglang.srt.distributed.parallel_state.init_model_parallel_group -> \
              sgl_kernel.patch.distributed.parallel_state.kunlun_init_model_parallel_group")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_parallel_state_patch()