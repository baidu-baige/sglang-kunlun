"""eagle_info"""

import torch
import torch.nn.functional as F
from sglang.srt.managers.schedule_batch import ScheduleBatch
from sglang.srt.layers.logits_processor import LogitsProcessorOutput
from sglang.srt.mem_cache.allocator import BaseTokenToKVPoolAllocator
from sglang.srt.model_executor.forward_batch_info import CaptureHiddenMode
from sglang.srt.layers.sampler import apply_custom_logit_processor
from sglang.srt.server_args import get_global_server_args
from sglang.srt.speculative.spec_utils import (
    SIMULATE_ACC_LEN,
    TREE_SPEC_KERNEL_AVAILABLE,
    create_accept_length_filter,
    generate_simulated_accept_index,
    get_src_tgt_cache_loc,
)
from sgl_kernel.patch.speculative.spec_utils import assign_req_to_token_pool_func_kunlun as \
    assign_req_to_token_pool_func
from sgl_kernel.patch.speculative.spec_utils import (
    align_evict_mask_to_page_size_func,
    create_extend_after_decode_spec_info_func,
    filter_finished_cache_loc_func
)

from sgl_kernel.patch.speculative.speculative_klx import (
    tree_speculative_sampling_target_only_kunlun,
    verify_tree_greedy_func_kunlun
)
from sgl_kernel import top_k_renorm_prob, top_p_renorm_prob

from sglang.srt.speculative.eagle_info import EagleVerifyInput, EagleVerifyOutput, EagleDraftInput
from typing import Optional


def verify_kunlun(
    self,
    batch: ScheduleBatch,
    logits_output: LogitsProcessorOutput,
    token_to_kv_pool_allocator: BaseTokenToKVPoolAllocator,
    page_size: int,
    vocab_mask: Optional[torch.Tensor] = None,  # For grammar
) -> torch.Tensor:
    """
        Verify and find accepted tokens based on logits output and batch
        (which contains spec decoding information).

        WARNING: This API in-place modifies the states of logits_output

        This API updates values inside logits_output based on the accepted
        tokens. I.e., logits_output.next_token_logits only contains
        accepted token logits.
    """
    if batch.forward_mode.is_idle():
        return EagleVerifyOutput(
            draft_input=EagleDraftInput.create_idle_input(
                device=batch.device,
                hidden_size=batch.model_config.hidden_size,
                dtype=batch.model_config.dtype,
                topk=self.topk,
                capture_hidden_mode=CaptureHiddenMode.LAST,
            ),
            logits_output=logits_output,
            verified_id=torch.empty(0, dtype=torch.long, device=batch.device),
            accept_length_per_req_cpu=[],
            accepted_indices=torch.full(
                (0, self.spec_steps + 1),
                -1,
                dtype=torch.int32,
                device=batch.device,
            ),
        )

    bs = self.retrive_index.shape[0]
    candidates = self.draft_token.reshape(bs, self.draft_token_num)
    sampling_info = batch.sampling_info

    predict_shape = list(logits_output.next_token_logits.shape)[:-1]
    predict_shape[-1] += 1
    predict = torch.empty(predict_shape, dtype=torch.int32, device=batch.device)
    accept_index = torch.full(
        (bs, self.spec_steps + 1), -1, dtype=torch.int32, device=batch.device
    )
    accept_length = torch.empty((bs,), dtype=torch.int32, device=batch.device)

    if bs != len(sampling_info):
        sampling_info = copy.deepcopy(sampling_info)
        # NOTE: retrive_index are the indices of the requests that are kept.
        sampling_info.filter_batch(self.retrive_index.tolist(), self.retrive_index)

    # Apply the custom logit processors if registered in the sampling info.
    if sampling_info.has_custom_logit_processor:
        apply_custom_logit_processor(
            logits_output.next_token_logits,
            sampling_info,
            num_tokens_in_batch=self.draft_token_num,
        )

    # Apply penalty
    if (
        sampling_info.penalizer_orchestrator.is_required
        or sampling_info.logit_bias is not None
    ):
        # This is a relaxed version of penalties for speculative decoding.
        linear_penalty = torch.zeros(
            (bs, logits_output.next_token_logits.shape[1]),
            dtype=torch.float32,
            device=batch.device,
        )
        sampling_info.apply_logits_bias(linear_penalty)
        logits_output.next_token_logits.add_(
            torch.repeat_interleave(linear_penalty, self.draft_token_num, dim=0)
        )

    # Apply grammar mask
    if vocab_mask is not None:
        assert self.grammar is not None
        self.grammar.apply_vocab_mask(
            logits=logits_output.next_token_logits, vocab_mask=vocab_mask
        )

    # Sample tokens. Force greedy sampling on AMD
    is_all_greedy = sampling_info.is_all_greedy
    if (not is_all_greedy) and (not TREE_SPEC_KERNEL_AVAILABLE):
        logger.warning(
            "Tree speculative sampling kernel unavailable (likely AMD/HIP build). "
            "Falling back to greedy verification."
        )

    if is_all_greedy or not TREE_SPEC_KERNEL_AVAILABLE:
        target_predict = torch.argmax(logits_output.next_token_logits, dim=-1)
        target_predict = target_predict.reshape(bs, self.draft_token_num)
        predict, accept_index, accept_length = verify_tree_greedy_func_kunlun(
            predicts=predict,  # mutable
            accept_index=accept_index,  # mutable
            accept_token_num=accept_length,  # mutable
            candidates=candidates,
            retrive_index=self.retrive_index,
            retrive_next_token=self.retrive_next_token,
            retrive_next_sibling=self.retrive_next_sibling,
            target_predict=target_predict,
            topk=self.topk,
        )

    else:
        # apply temperature and get target probs
        expanded_temperature = torch.repeat_interleave(
            sampling_info.temperatures, self.draft_token_num, dim=0
        )  # (bs * draft_token_num, 1)

        target_probs = F.softmax(
            logits_output.next_token_logits / expanded_temperature, dim=-1
        )  # (bs * draft_token_num, vocab_size)
        target_probs = top_k_renorm_prob(
            target_probs,
            torch.repeat_interleave(
                sampling_info.top_ks, self.draft_token_num, dim=0
            ),
        )  # (bs * draft_token_num, vocab_size)
        if not torch.all(sampling_info.top_ps == 1.0):
            target_probs = top_p_renorm_prob(
                target_probs,
                torch.repeat_interleave(
                    sampling_info.top_ps, self.draft_token_num, dim=0
                ),
            )
        target_probs = target_probs.reshape(bs, self.draft_token_num, -1)

        draft_probs = torch.zeros(
            target_probs.shape, dtype=torch.float32, device=batch.device
        )

        # coins for rejection sampling
        coins = torch.rand_like(
            candidates, dtype=torch.float32, device=batch.device
        )
        # coins for final sampling
        coins_for_final_sampling = torch.rand(
            (bs,), dtype=torch.float32, device=batch.device
        )
        tree_speculative_sampling_target_only_kunlun(
            predicts=predict,  # mutable
            accept_index=accept_index,  # mutable
            accept_token_num=accept_length,  # mutable
            candidates=candidates,
            retrive_index=self.retrive_index,
            retrive_next_token=self.retrive_next_token,
            retrive_next_sibling=self.retrive_next_sibling,
            uniform_samples=coins,
            uniform_samples_for_final_sampling=coins_for_final_sampling,
            target_probs=target_probs,
            draft_probs=draft_probs,
            threshold_single=get_global_server_args().speculative_accept_threshold_single,
            threshold_acc=get_global_server_args().speculative_accept_threshold_acc,
            deterministic=True,
        )

    if SIMULATE_ACC_LEN > 0.0:
        # Do simulation
        accept_index = generate_simulated_accept_index(
            accept_index=accept_index,
            predict=predict,  # mutable
            accept_length=accept_length,  # mutable
            bs=bs,
            spec_steps=self.spec_steps,
        )

    for i, req in enumerate(batch.reqs):
        start = i * self.draft_token_num
        count = req.inject_thinking_prompt_tokens(
            predict,
            start_idx=start,
            max_count=self.draft_token_num,
            advance=True,
        )
        if count <= 0:
            continue
        accept_index[i].fill_(-1)
        accept_index[i, :count] = torch.arange(
            start, start + count, dtype=accept_index.dtype, device=predict.device
        )
        accept_length[i] = count - 1

    unfinished_index = []
    unfinished_accept_index = []
    accept_index_cpu = accept_index.tolist()
    predict_cpu = predict.tolist()
    has_finished = False

    # Iterate every accepted token and check if req has finished after append the token
    # should be checked BEFORE free kv cache slots
    for i, (req, accept_index_row) in enumerate(zip(batch.reqs, accept_index_cpu)):
        num_accepted = 0
        for j, idx in enumerate(accept_index_row):
            if idx == -1:
                break
            num_accepted += 1
            id = predict_cpu[idx]
            req.output_ids.append(id)
            req.update_thinking_state([id])
            req.check_finished()
            if req.finished():
                has_finished = True
                # set all tokens after finished token to -1 and break
                accept_index[i, j + 1 :] = -1
                break
            else:
                if req.grammar is not None:
                    try:
                        req.grammar.accept_token(id)
                    except ValueError as e:
                        logger.info(
                            f"{i=}, {req=}\n" f"{accept_index=}\n" f"{predict=}\n"
                        )
                        raise e
        # Update KV cache tracking for the accepted tokens
        req.kv_committed_len += num_accepted
        req.kv_allocated_len = req.kv_committed_len
        if not req.finished():
            unfinished_index.append(i)
            if idx == -1:
                unfinished_accept_index.append(accept_index[i, :j])
            else:
                unfinished_accept_index.append(accept_index[i])
        req.spec_verify_ct += 1
        req.spec_accepted_tokens += (
            sum(1 for idx in accept_index_row if idx != -1) - 1
        )

    if has_finished:
        accept_length = (accept_index != -1).sum(dim=1) - 1

    # Free the KV cache for unaccepted tokens
    # TODO: fuse them
    accept_index = accept_index[accept_index != -1]
    verified_id = predict[accept_index]
    evict_mask = torch.full_like(self.draft_token, True, dtype=torch.bool)
    evict_mask[accept_index] = False
    accept_length_cpu = accept_length.cpu()
    # FIXME: this `tolist()` fixes the numerical calculation consistency
    # try to unify the tensor representation and list representation
    accept_length_list = accept_length_cpu.tolist()

    if page_size == 1:
        # TODO: boolean array index leads to a device sync. Remove it.
        token_to_kv_pool_allocator.free(batch.out_cache_loc[evict_mask])
    else:
        if self.topk == 1:
            # Only evict full empty page. Do not evict partial empty page
            align_evict_mask_to_page_size_func(
                batch.seq_lens,
                evict_mask,
                page_size,
                self.draft_token_num,
            )
            token_to_kv_pool_allocator.free(batch.out_cache_loc[evict_mask])
        else:
            # Shift the accepted tokens to the beginning.
            # Only evict the last part
            src_cache_loc, tgt_cache_loc, to_free_num_slots = get_src_tgt_cache_loc(
                batch.seq_lens,
                batch.out_cache_loc,
                accept_index,
                accept_length,
                self.draft_token_num,
                page_size,
            )
            to_free_slots = torch.empty(
                (to_free_num_slots.sum().item(),),
                dtype=torch.int64,
                device=to_free_num_slots.device,
            )

            # out_cache_loc: [0  1  2,  3  4  5,  6  7  8]
            # accept_index:  [0 -1  2,  3  4 -1,  6 -1 -1]
            # tgt_cache_loc: [0  1   ,  3  4   ,  6      ]
            # to_free_slots: [      2,        5,     7  8]
            # to_free_slots also needs to be page-aligned without the first partial page
            #
            # split each row of out_cache_loc into two parts.
            # 1. the first part goes to tgt_cache_loc. length = accept_length[i] + 1
            # 2. the second part goes to to_free_slots.
            get_target_cache_loc[(bs,)](
                tgt_cache_loc,
                to_free_slots,
                accept_length,
                to_free_num_slots,
                batch.out_cache_loc,
                self.draft_token_num,
                next_power_of_2(self.draft_token_num),
                next_power_of_2(bs),
            )

            # Free the kv cache
            token_to_kv_pool_allocator.free(to_free_slots)

            # Copy the kv cache
            batch.token_to_kv_pool_allocator.get_kvcache().move_kv_cache(
                tgt_cache_loc, src_cache_loc
            )

    # Construct EagleVerifyOutput
    if not has_finished:
        if page_size == 1 or self.topk == 1:
            batch.out_cache_loc = batch.out_cache_loc[accept_index]
            assign_req_to_token_pool_func(
                batch.req_pool_indices,
                batch.req_to_token_pool.req_to_token,
                batch.seq_lens,
                batch.seq_lens + accept_length + 1,
                batch.out_cache_loc,
                bs,
            )
        else:
            batch.out_cache_loc = tgt_cache_loc
        batch.seq_lens.add_(accept_length + 1)
        batch.seq_lens_cpu.add_(accept_length_cpu + 1)

        draft_input = EagleDraftInput(
            hidden_states=batch.spec_info.hidden_states[accept_index],
            verified_id=verified_id,
            accept_length=accept_length,
            accept_length_cpu=accept_length_list,
            seq_lens_for_draft_extend=batch.seq_lens,
            seq_lens_for_draft_extend_cpu=batch.seq_lens_cpu,
            req_pool_indices_for_draft_extend=batch.req_pool_indices,
        )

        return EagleVerifyOutput(
            draft_input=draft_input,
            logits_output=logits_output,
            verified_id=verified_id,
            accept_length_per_req_cpu=draft_input.accept_length_cpu,
            accepted_indices=accept_index,
        )
    else:
        if page_size == 1 or self.topk == 1:
            assign_req_to_token_pool_func(
                batch.req_pool_indices,
                batch.req_to_token_pool.req_to_token,
                batch.seq_lens,
                batch.seq_lens + accept_length + 1,
                batch.out_cache_loc[accept_index],
                bs,
            )
            batch.seq_lens.add_(accept_length + 1)
            batch.seq_lens_cpu.add_(accept_length_cpu + 1)

        if len(unfinished_accept_index) > 0:
            unfinished_accept_index = torch.cat(unfinished_accept_index)
            unfinished_index_device = torch.tensor(
                unfinished_index, dtype=torch.int64, device=predict.device
            )
            draft_input_accept_length_cpu = [
                accept_length_list[i] for i in unfinished_index
            ]
            if page_size == 1 or self.topk == 1:
                batch.out_cache_loc = batch.out_cache_loc[unfinished_accept_index]
            else:
                batch.out_cache_loc = torch.empty(
                    len(unfinished_index) + sum(draft_input_accept_length_cpu),
                    dtype=torch.int64,
                    device=predict.device,
                )
                accept_length_filter = create_accept_length_filter(
                    accept_length,
                    unfinished_index_device,
                    batch.seq_lens,
                )
                batch.seq_lens_cpu.add_(accept_length_cpu + 1)
                filter_finished_cache_loc_func(
                    batch.out_cache_loc,
                    tgt_cache_loc,
                    accept_length,
                    accept_length_filter,
                    self.draft_token_num,
                    bs
                )

            draft_input = EagleDraftInput(
                hidden_states=batch.spec_info.hidden_states[
                    unfinished_accept_index
                ],
                verified_id=predict[unfinished_accept_index],
                accept_length_cpu=draft_input_accept_length_cpu,
                accept_length=accept_length[unfinished_index_device],
                seq_lens_for_draft_extend=batch.seq_lens[unfinished_index_device],
                seq_lens_for_draft_extend_cpu=batch.seq_lens_cpu[unfinished_index],
                req_pool_indices_for_draft_extend=batch.req_pool_indices[
                    unfinished_index_device
                ],
            )
        else:
            draft_input = EagleDraftInput.create_idle_input(
                device=batch.device,
                hidden_size=batch.model_config.hidden_size,
                dtype=batch.model_config.dtype,
                topk=self.topk,
                capture_hidden_mode=CaptureHiddenMode.LAST,
            )

        return EagleVerifyOutput(
            draft_input=draft_input,
            logits_output=logits_output,
            verified_id=verified_id,
            accept_length_per_req_cpu=accept_length_list,
            accepted_indices=accept_index,
        )


def prepare_extend_after_decode_kunlun(
    self,
    batch: ScheduleBatch,
    speculative_num_steps: int,
):
    '''prepare_extend_after_decode_kunlun'''
    if batch.forward_mode.is_idle():
        return

    batch.input_ids = self.verified_id
    batch.extend_lens = [x + 1 for x in batch.spec_info.accept_length_cpu]
    batch.extend_num_tokens = sum(batch.extend_lens)
    batch.seq_lens = batch.spec_info.seq_lens_for_draft_extend
    batch.seq_lens_cpu = batch.spec_info.seq_lens_for_draft_extend_cpu
    batch.req_pool_indices = batch.spec_info.req_pool_indices_for_draft_extend
    batch.return_logprob = False
    batch.return_hidden_states = False

    self.capture_hidden_mode = CaptureHiddenMode.LAST
    self.accept_length.add_(1)
    self.positions = torch.empty_like(batch.input_ids, dtype=torch.long)
    self.verified_id = torch.empty_like(self.accept_length, dtype=torch.int32)

    create_extend_after_decode_spec_info_func(
        batch.input_ids,
        batch.seq_lens,
        self.accept_length,
        self.positions,
        self.verified_id,
        speculative_num_steps,
    )


def eagle_info_patch():
    """
    eagle_info_patch
    """
    try:
        EagleVerifyInput.verify = verify_kunlun
        EagleDraftInput.prepare_extend_after_decode = prepare_extend_after_decode_kunlun
        print("[Patch] EagleVerifyInput patched successfully.")
        print("[Patch] EagleDraftInput.prepare_extend_after_decode patched successfully.")
    except ImportError as e:
        print(f"[Patch Error] Failed to patch eagle_info: {e}")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

eagle_info_patch()