"""spec_utils"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List, Optional
import torch
import xspeedgate_ops

from sglang.srt.environ import envs
from sglang.srt.server_args import ServerArgs, get_global_server_args
from sglang.srt.utils import is_cuda, next_power_of_2
 
logger = logging.getLogger(__name__)


# Simulate acceptance length for benchmarking purposes
SIMULATE_ACC_LEN = envs.SGLANG_SIMULATE_ACC_LEN.get()  # turn off if < 0
SIMULATE_ACC_METHOD = envs.SGLANG_SIMULATE_ACC_METHOD.get()

TREE_TRAVERSE_TIME_THRESHOLD = 1  # TODO: set this properly
TREE_SPEC_KERNEL_AVAILABLE = is_cuda()  # This kernel is only available for CUDA now


def spec_need_hidden_states(server_args: Optional[ServerArgs] = None) -> bool:
    '''spec_need_hidden_states'''
    if server_args is None:
        server_args = get_global_server_args()

    # TODO(lsyin): also skip when 1) step = 1 or 2) standalone draft model
    return not server_args.enable_multi_layer_eagle


def create_extend_spec_info_torch_native(
    batch_size,
    verified_id,
    seq_lens,
    accept_lens,
    positions,
    new_verified_id,
):
    """create_extend_spec_info torch native"""
    accept_len_cum = torch.cumsum(accept_lens, axis=0, dtype=torch.int)
    # Process each batch item
    for pid in range(batch_size):
        # Calculate offset for current batch item
        offset = 0 if pid == 0 else accept_len_cum[pid - 1].item()

        # Get sequence length and accept length for current batch
        seq_length = seq_lens[pid].item()
        accept_length = accept_lens[pid].item()

        # Calculate positions for accepted tokens
        if accept_length > 0:
            # Create range for accepted tokens
            data = torch.arange(accept_length, device=positions.device)
            # Calculate positions: seq_length - accept_length + data
            pos_values = seq_length - accept_length + data
            # Store positions
            positions[offset : offset + accept_length] = pos_values

        # Get the last verified token id for this batch
        verified_offset = accept_len_cum[pid].item() - 1
        verified_id_data = verified_id[verified_offset]
        new_verified_id[pid] = verified_id_data


def create_extend_after_decode_spec_info_func(
    verified_id,
    seq_lens,
    accept_lens,
    positions,
    new_verified_id,
    speculative_num_steps
):
    '''create_extend_after_decode_spec_info_func'''
    batch_size = len(seq_lens)
    create_extend_spec_info_torch_native(
        batch_size,
        verified_id,
        seq_lens,
        accept_lens,
        positions,
        new_verified_id,
    )


def assign_req_to_token_pool_torch_native(
    req_pool_indices: torch.Tensor,
    req_to_token: torch.Tensor,
    start_offset: torch.Tensor,    
    end_offset: torch.Tensor,
    out_cache_loc: torch.Tensor,
    pool_len: int,
):
    """assign_req_to_token_pool_torch_native"""
    num_requests = req_pool_indices.shape[0]

    lengths = end_offset - start_offset
    cumsum_lengths = torch.cat([
        torch.zeros(1, device=lengths.device, dtype=lengths.dtype), 
        torch.cumsum(lengths, dim=0)[:-1]
    ])

    for pid in range(num_requests):
        kv_start = start_offset[pid].item()
        kv_end = end_offset[pid].item()
        length = kv_end - kv_start

        if length > 0:
            pool_idx = req_pool_indices[pid].item()
            out_offset = cumsum_lengths[pid].item()

            # Copy data
            req_to_token[pool_idx, kv_start:kv_end] = out_cache_loc[out_offset:out_offset + length]


def align_evict_mask_to_page_size_torch_native(
    seq_lens: torch.Tensor,
    evict_mask: torch.Tensor,
    page_size: int,
    num_draft_tokens: int,
    batch_size,
):
    """align_evict_mask_to_page_size torch native"""

    # Reshape evict_mask to [batch_size, num_draft_tokens] if needed
    evict_mask_2d = evict_mask.view(batch_size, num_draft_tokens)
    for bid in range(batch_size):
        seq_len = seq_lens[bid].item()
        mask_row = evict_mask_2d[bid, :num_draft_tokens]
        num_trues = mask_row.sum().item()
        num_false = num_draft_tokens - num_trues
        # Calculate start position
        start = ((seq_len + num_false - 1) // page_size) * page_size - seq_len
        # Set mask to False in the calculated range
        range_start = max(start, 0)
        range_end = min(start + page_size, num_draft_tokens)
        if range_start < range_end:
            evict_mask_2d[bid, range_start:range_end] = False


def align_evict_mask_to_page_size_func(
    seq_lens: torch.Tensor,
    evict_mask: torch.Tensor,
    page_size: int,
    draft_token_num: int, 
):
    '''align_evict_mask_to_page_size_func'''
    torch.ops.xspeedgate_ops.align_evict_mask_to_page_size(
        seq_lens,
        evict_mask,
        page_size,
        draft_token_num,
        next_power_of_2(draft_token_num),
    )


@torch.compile(dynamic=True)
def get_src_tgt_cache_loc(
    seq_lens: torch.Tensor,
    out_cache_loc: torch.Tensor,
    accept_index: torch.Tensor,
    accept_length: torch.Tensor,
    draft_token_num: int,
    page_size: int,
):
    '''get_src_tgt_cache_loc'''
    src_cache_loc = out_cache_loc[accept_index]
    tgt_cache_loc = torch.empty_like(src_cache_loc)
    extended_len = seq_lens + draft_token_num
    keep_len = torch.minimum(
        (seq_lens + accept_length + 1 + page_size - 1) // page_size * page_size,
        extended_len,
    )
    to_free_num_slots = extended_len - keep_len
    return src_cache_loc, tgt_cache_loc, to_free_num_slots


def filter_finished_cache_loc_kernel_torch_native(
    out_cache_loc: torch.Tensor,
    tgt_cache_loc: torch.Tensor,
    accept_length: torch.Tensor,
    accept_length_filter: torch.Tensor,
    batch_size: int
):
    """filter_finished_cache_loc_kernel_torch_native"""
    for bid in range(batch_size):
        accept_length_all = accept_length[:bid]
        old_start = accept_length_all.sum().item() + bid

        accept_length_filter_all = accept_length_filter[:bid]
        new_start = accept_length_filter_all.sum().item()

        copy_len = accept_length_filter[bid].item()
        if copy_len > 0:
            value = tgt_cache_loc[old_start:old_start + copy_len]
            out_cache_loc[new_start:new_start + copy_len] = value


def filter_finished_cache_loc_func(
    out_cache_loc: torch.Tensor,
    tgt_cache_loc: torch.Tensor,
    accept_length: torch.Tensor,
    accept_length_filter: torch.Tensor,
    draft_token_num: int,
    batch_size: int
):
    '''filter_finished_cache_loc_func'''
    filter_finished_cache_loc_kernel_torch_native(
        out_cache_loc,
        tgt_cache_loc,
        accept_length,
        accept_length_filter,
        batch_size
    )


def assign_req_to_token_pool_func_kunlun(
    req_pool_indices: torch.Tensor,
    req_to_token: torch.Tensor,
    start_offset: torch.Tensor,
    end_offset: torch.Tensor,
    out_cache_loc: torch.Tensor,
    batch_size: int,
):
    '''assign_req_to_token_pool_func_kunlun'''
    torch.ops.xspeedgate_ops.assign_req_to_token_pool(
        req_pool_indices,
        req_to_token,
        start_offset,
        end_offset,
        out_cache_loc,
        req_to_token.shape[1],
        batch_size,
    )


def spec_utils_patch():
    """
    spec_utils_patch
    """
    try:
        import sglang.srt.speculative.spec_utils as spec_utils_module
        spec_utils_module.assign_req_to_token_pool_func = assign_req_to_token_pool_torch_native
        print("[Patch] spec_utils.assign_req_to_token_pool_func patched successfully.")
    except ImportError as e:
        print(f"[Patch Error] Failed to patch sglang.srt.speculative.spec_utils: {e}")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

spec_utils_patch()