"""
Wrapper functions for kunlun operators
"""

import torch
from kunlun_ops import (
    build_tree,
    build_tree_efficient,
    verify_tree_greedy,
    tree_speculative_sampling_target_only,
)


def build_tree_xops(
    parent_list,
    selected_index,
    verified_seq_len,
    tree_mask,
    positions,
    retrive_index,
    topk,
    depth,
    draft_token_num,
):
    """
    Wrapper
    """
    batch_size = verified_seq_len.numel()
    seq_lens_sum = -1  # Use default value

    build_tree(
        parent_list,
        selected_index,
        verified_seq_len,
        tree_mask,
        positions,
        retrive_index,
        topk,
        depth,
        draft_token_num,
        batch_size,
        seq_lens_sum,
    )


def build_tree_efficient_xops(
    parent_list: torch.Tensor,
    selected_index: torch.Tensor,
    verified_seq_len: torch.Tensor,
    tree_mask: torch.Tensor,
    positions: torch.Tensor,
    retrive_index: torch.Tensor,
    retrive_next_token: torch.Tensor,
    retrive_next_sibling: torch.Tensor,
    topk: int,
    depth: int,
    draft_token_num: int,
    tree_mask_mode: int, # not used
):
    """
    Wrapper
    """
    batch_size = verified_seq_len.numel()
    seq_lens_sum = -1  # Use default value
    # for kunlun operator, verified_seq_len and retrive_index are required to be int32 and long type respectively
    verified_seq_len = verified_seq_len.to(torch.int32)
    retrive_index = retrive_index.to(torch.long)
    retrive_next_token = retrive_next_token.to(torch.long)
    retrive_next_sibling = retrive_next_sibling.to(torch.long)
    build_tree_efficient(
        parent_list,
        selected_index,
        verified_seq_len,
        tree_mask,
        positions,
        retrive_index,
        retrive_next_token,
        retrive_next_sibling,
        topk,
        depth,
        draft_token_num,
        batch_size,
        seq_lens_sum,
    )


def tree_speculative_sampling_target_only_kunlun(
    predicts: torch.Tensor,  # mutable
    accept_index: torch.Tensor,  # mutable
    accept_token_num: torch.Tensor,  # mutable
    candidates: torch.Tensor,
    retrive_index: torch.Tensor,
    retrive_next_token: torch.Tensor,
    retrive_next_sibling: torch.Tensor,
    uniform_samples: torch.Tensor,
    uniform_samples_for_final_sampling: torch.Tensor,
    target_probs: torch.Tensor,
    draft_probs: torch.Tensor,
    threshold_single: float = 0.3,
    threshold_acc: float = 0.3,
    deterministic: bool = True,   # not used
):
    """
    Wrapper
    """
    batch_size = candidates.size(0)
    num_spec_step = len(accept_index[0])
    num_draft_tokens = retrive_next_token.size(1)
    vocab_size = target_probs.size(-1)
    tree_speculative_sampling_target_only(
        candidates.to(torch.int32),
        retrive_index.to(torch.int32),
        retrive_next_token.to(torch.int32),
        retrive_next_sibling.to(torch.int32),
        uniform_samples,
        target_probs,
        batch_size,
        num_spec_step,
        num_draft_tokens,
        vocab_size,
        threshold_single,
        threshold_acc,
        predicts[:-1].view(batch_size, num_draft_tokens),
        accept_index,
        accept_token_num,
        draft_probs,
    )


def verify_tree_greedy_func_kunlun(
    predicts: torch.Tensor,  # mutable
    accept_index: torch.Tensor,  # mutable
    accept_token_num: torch.Tensor,  # mutable
    candidates: torch.Tensor,
    retrive_index: torch.Tensor,
    retrive_next_token: torch.Tensor,
    retrive_next_sibling: torch.Tensor,
    target_predict: torch.Tensor,
    topk: int = -1,
):
    """
    Wrapper
    """
    verify_tree_greedy(
        predicts,
        accept_index,
        accept_token_num,
        candidates,
        retrive_index,
        retrive_next_token,
        retrive_next_sibling,
        target_predict,
    )
    return predicts, accept_index, accept_token_num
