"""patch for eagle_worker
"""
import torch
import xspeedgate_ops

from sglang.srt.mem_cache.chunk_cache import SWAChunkCache
from sglang.srt.mem_cache.common import (
    alloc_paged_token_slots_extend,
    alloc_token_slots,
)
from sglang.srt.speculative.eagle_worker import get_last_loc_large_page_size_top_k_1
from sglang.srt.speculative.spec_utils import get_last_loc_large_page_size_large_top_k


def _draft_preprocess_decode_kunlun(self, batch: "ScheduleBatch"):
    batch.maybe_evict_swa()
    for req in batch.reqs:
        req.decode_batch_idx += 1

    # Parse args
    num_seqs = batch.batch_size()
    spec_info = batch.spec_info

    # Accumulate penalty
    if batch.sampling_info.penalizer_orchestrator.is_required:
        # This is a relaxed version of penalties for speculative decoding.
        batch.sampling_info.penalizer_orchestrator.cumulate_output_tokens(
            spec_info.verified_id.to(torch.int64)
        )

    # Allocate cache locations
    # Layout of the out_cache_loc
    # [       topk 0         ] [       topk 1         ]
    # [iter=0, iter=1, iter=2] [iter=0, iter=1, iter=2]
    if self.page_size == 1:
        # TODO: We only need self.speculative_num_steps - 1 * topk cache loc
        alloc_len_per_decode = self.speculative_num_steps * self.topk
        out_cache_loc, token_to_kv_pool_state_backup = alloc_token_slots(
            batch.tree_cache,
            num_seqs * alloc_len_per_decode,
            backup_state=True,
        )
    else:
        if self.topk == 1:
            prefix_lens, seq_lens, last_loc = get_last_loc_large_page_size_top_k_1(
                batch.req_to_token_pool.req_to_token,
                batch.req_pool_indices,
                batch.seq_lens,
                self.speculative_num_steps,
            )
            prefix_lens_cpu = batch.seq_lens_cpu
            seq_lens_cpu = batch.seq_lens_cpu + self.speculative_num_steps
            extend_num_tokens = num_seqs * self.speculative_num_steps
        else:
            # In this case, the last partial page needs to be duplicated.
            # KV cache layout in batch.req_to_token_pool.req_to_token:
            #
            # | -------- | -- xxxx .. | -- xxxx .. | -- xxxx .. |
            #    prefix     top-k = 0    tok-k = 1    top-k = 2
            #
            #  "-" means prefix tokens
            #  "x" means speculative draft tokens
            #  "." means padded tokens

            (
                prefix_lens,
                seq_lens,
                last_loc,
                self.num_new_pages_per_topk,
                self.extend_lens,
                last_page_lens,
            ) = get_last_loc_large_page_size_large_top_k(
                batch.req_to_token_pool.req_to_token,
                batch.req_pool_indices,
                batch.seq_lens,
                self.speculative_num_steps,
                self.topk,
                self.page_size,
            )
            prefix_lens_cpu = batch.seq_lens_cpu
            last_page_lens_cpu = prefix_lens_cpu % self.page_size
            num_new_pages_per_topk = (
                last_page_lens_cpu + self.speculative_num_steps + self.page_size - 1
            ) // self.page_size
            seq_lens_cpu = (
                prefix_lens_cpu // self.page_size * self.page_size
                + num_new_pages_per_topk * (self.page_size * self.topk)
            )
            extend_num_tokens = torch.sum((seq_lens_cpu - prefix_lens_cpu)).item()

        out_cache_loc, token_to_kv_pool_state_backup = (
            alloc_paged_token_slots_extend(
                batch.tree_cache,
                prefix_lens,
                prefix_lens_cpu,
                seq_lens,
                seq_lens_cpu,
                last_loc,
                extend_num_tokens,
                backup_state=True,
            )
        )

    if self.page_size > 1 and self.topk > 1:
        last_page_lens_cumsum = torch.cumsum(last_page_lens, dim=0)
        duplicate_cache_len = torch.sum(last_page_lens_cpu).item() * (self.topk - 1)
        target_cache_loc = torch.zeros(
            duplicate_cache_len, dtype=torch.int32, device=self.device
        )
        source_cache_loc = torch.zeros(
            duplicate_cache_len, dtype=torch.int32, device=self.device
        )
    else:
        # When source_cache_loc is not needed, simply skip
        duplicate_cache_len = 0
        source_cache_loc, target_cache_loc, last_page_lens_cumsum = None, None, None

    # assign_draft_cache_locs[(num_seqs,)](
    #     batch.req_pool_indices,
    #     batch.req_to_token_pool.req_to_token,
    #     batch.seq_lens,
    #     self.extend_lens,
    #     self.num_new_pages_per_topk,
    #     out_cache_loc,
    #     source_cache_loc,
    #     target_cache_loc,
    #     last_page_lens_cumsum,
    #     duplicate_cache_len,
    #     batch.req_to_token_pool.req_to_token.shape[1],
    #     self.topk,
    #     self.speculative_num_steps,
    #     self.page_size,
    #     next_power_of_2(num_seqs),
    #     next_power_of_2(self.speculative_num_steps + self.page_size),
    # )

    # for kunlun
    torch.ops.xspeedgate_ops.assign_draft_cache_locs(
        batch.req_pool_indices,
        batch.req_to_token_pool.req_to_token,
        batch.seq_lens,
        self.extend_lens,
        self.num_new_pages_per_topk,
        out_cache_loc,
        pool_len=batch.req_to_token_pool.req_to_token.shape[1],
        topk=self.topk,
        speculative_num_steps=self.speculative_num_steps,
        page_size=self.page_size,
    )

    if self.page_size > 1 and self.topk > 1:
        if duplicate_cache_len > 0:
            self.draft_model_runner.token_to_kv_pool.move_kv_cache(
                target_cache_loc, source_cache_loc
            )
        # Remove padded slots
        # TODO: We only need self.speculative_num_steps - 1 cache loc
        out_cache_loc = out_cache_loc[
            : num_seqs * self.topk * self.speculative_num_steps
        ]

    batch.out_cache_loc = out_cache_loc
    batch.seq_lens_sum = torch.sum(batch.seq_lens).item()
    batch.return_hidden_states = False
    spec_info.positions = batch.seq_lens.repeat_interleave(self.topk, dim=0)
    self.token_to_kv_pool_allocator.restore_state(token_to_kv_pool_state_backup)


def apply_eagle_worker_patch():
    """apply_eagle_worker_patch"""
    try:
        from sglang.srt.speculative.eagle_worker import EAGLEWorker
        EAGLEWorker._draft_preprocess_decode = _draft_preprocess_decode_kunlun
        print("[Patch] sglang.srt.speculative.eagle_worker.EAGLEWorker._draft_preprocess_decode -> \
            sgl_kernel.patch.speculative.eagle_worker._draft_preprocess_decode_kunlun")
    except Exception as e:
        print(f"[Patch Error] Unexpected error: {e}")

apply_eagle_worker_patch()