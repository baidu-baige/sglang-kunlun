"""
This module provides functionality related to flash operations through the sgl_kernel.
"""

from sgl_kernel import flash_ops