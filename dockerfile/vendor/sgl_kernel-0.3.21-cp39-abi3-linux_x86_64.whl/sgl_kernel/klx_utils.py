"""
This module provides utilities for environment variable parsing, function decoration,
and timing analysis.
"""

import os
import time
from functools import lru_cache, wraps
from typing import Callable


@lru_cache
def get_bool_env_var(name: str, default: str = "false") -> bool:
    """
    Gets a boolean environment variable.
    
    Args:
        name (str): The name of the environment variable.
        default (str): The default value if the environment variable is not set.
    
    Returns:
        bool: The boolean value of the environment variable.
    """
    value = os.getenv(name, default)
    return value.lower() in ("true", "1")


def klx_register(klx_func: Callable, fallback: bool):
    """
    A decorator for registering fallback functions.
    
    Args:
        klx_func (Callable): The function to be used if the fallback is not triggered.
        fallback (bool): Whether to use the fallback logic.
    
    Returns:
        function: The decorated function.
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            if fallback and get_bool_env_var("KLX_FALLBACK"):
                return func(*args, **kwargs)
            else:
                return klx_func(*args, **kwargs)

        wrapper.original_function = func
        return wrapper

    return decorator


class Record(object):
    """
    A class for recording and reporting timing information.
    """
    def __init__(self) -> None:
        print("init Record", self)
        self.timing_cache = {}

    def record(self, key, append_value):
        """
        Records a value for a given key.
        
        Args:
            key: The key to record the value under.
            append_value: The value to record.
        """
        if key in self.timing_cache.keys():
            self.timing_cache[key].append(append_value)
        else:
            self.timing_cache[key] = [append_value]

    def report_self(self):
        """
        Reports the recorded timing information.
        """
        for key, values in self.timing_cache.items():
            if not values:
                continue
            min_value = min(values)
            max_value = max(values)
            avg_value = sum(values) / len(values)
            # Sort values to find the P999 value
            sorted_values = sorted(values)
            p999_index = int(len(sorted_values) * 0.999) - 1
            p999_value = sorted_values[min(p999_index, len(sorted_values) - 1)]
            print(f"Function : {key}")
            print(f"  Min: {min_value}")
            print(f"  Max: {max_value}")
            print(f"  Avg: {avg_value}")
            print(f"  P999: {p999_value}")


record = Record()


def timing_decorator(func):
    """
    A decorator for timing function execution.
    
    Args:
        func: The function to be timed.
    
    Returns:
        function: The decorated function.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not get_bool_env_var("KLX_ANALYSIS"):
            return func(*args, **kwargs)
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = (end_time - start_time) * 1000
        print(f"{func.__name__} {elapsed_time} ms")
        # record.record(func.__name__, elapsed_time)
        return result

    return wrapper