"""
This module contains utilities for setting options for xdnn context,
redirecting output, and other helper functions.
"""
import logging
import os
from datetime import datetime

import torch
import torch.distributed as dist

logger = logging.getLogger(__name__)

from sglang.srt.distributed import (
    get_tensor_model_parallel_rank,
    get_tensor_model_parallel_world_size,
    parallel_state,
    tensor_model_parallel_all_reduce,
)
from sglang.srt.utils import get_bool_env_var


def set_option_for_xdnn_context(option, value):
    """
    Set option for xdnn context, the option and value must be str.
    
    Args:
        option (str): The option to be set.
        value (str): The value to set for the option.
        
    Raises:
        ValueError: If option or value is not a string.
    """
    if not (isinstance(option, str) and isinstance(value, str)):
        raise ValueError("option and value must be str")
    dummy_torch_tensor = torch.empty(0).cuda()
    # torch 需要至少传递一个device tensor 才能work
    torch.ops.sgl_kernel.set_option_for_xdnn_context(dummy_torch_tensor, option, value)


class KLXKernelDebugger:
    """
    A context manager for setting and resetting an option in the xdnn context.
    
    Args:
        option (str): The option to be set.
        value (str): The value to set for the option.
    """

    def __init__(self, option, value):
        self._option = option
        # TODO: get old value from xdnn context
        self._old_value = "0x0"
        set_option_for_xdnn_context(option, value)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        set_option_for_xdnn_context(self._option, self._old_value)


def from_blob(ptr: int, num_element, dtype):
    """
    Creates a tensor from a blob of memory.
    
    Args:
        ptr (int): Pointer to the blob of memory.
        num_element (int): Number of elements in the blob.
        dtype: Data type of the elements.
        
    Returns:
        torch.Tensor: Tensor containing the data from the blob.
    """
    dummy_torch_tensor = torch.empty(0).cuda()
    return torch.ops.sgl_kernel.klx_from_blob.default(
        dummy_torch_tensor, ptr, num_element, dtype
    )


def generate_unique_dir_as_number():
    """
    Generates a unique directory name based on the current time.
    
    Returns:
        int: Unique directory name as an integer.
    """
    current_time = datetime.now()
    return int(current_time.strftime("%Y%m%d%H%M%S"))


run_once = False


def redirect_output():
    """
    Redirects stdout and stderr to a log file based on the tensor model parallel rank.
    """
    global run_once
    if run_once:
        return
    run_once = True
    rank = get_tensor_model_parallel_rank()
    dir_path = "./logs/"
    try:
        os.makedirs(dir_path, exist_ok=True)
    except FileExistsError:
        pass
    if rank == 0:
        print("[xSGL INFO] Redirect log to: " + dir_path)
    log_file = os.path.join(dir_path, f"rank{rank}.log")
    fd = os.open(log_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
    os.dup2(fd, 1)
    os.dup2(fd, 2)
    os.close(fd)
