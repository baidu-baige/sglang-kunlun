import torch
import kunlun_ops

def hadamard_transform(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    hidden_size = x.size(-1)
    hm = torch.empty((hidden_size, hidden_size), dtype=x.dtype, device=x.device)
    kunlun_ops.xpu_flash_ops.gen_hadamard_matrix(hm, scale)
    
    original_shape = x.shape
    if len(original_shape) > 2:
        x = x.view(-1, hidden_size)
    
    out = torch.empty_like(x, dtype=x.dtype, device=x.device)
    kunlun_ops.matmul(x, hm, out, False, True, 1.0, 0.0)
    
    if len(original_shape) > 2:
        out = out.view(*original_shape)
    
    return out


def hadamard_transform_12n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    return torch.ops.sgl_kernel.fast_hadamard_transform_12N.default(x, scale)


def hadamard_transform_20n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    return torch.ops.sgl_kernel.fast_hadamard_transform_20N.default(x, scale)


def hadamard_transform_28n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    return torch.ops.sgl_kernel.fast_hadamard_transform_28N.default(x, scale)


def hadamard_transform_40n(x: torch.Tensor, scale: float = 1.0) -> torch.Tensor:
    return torch.ops.sgl_kernel.fast_hadamard_transform_40N.default(x, scale)
