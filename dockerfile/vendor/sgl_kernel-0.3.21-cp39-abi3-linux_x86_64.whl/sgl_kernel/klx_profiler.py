import contextlib
import functools
import time
from typing import Any, Callable, Dict, Optional, Union

import torch


class PyTorchTimer(object):
    """
    PyTorch code performance timing and printing module
    Used to measure execution time and GPU memory usage of PyTorch code segments
    """

    def __init__(self, name: str = "Default Timer", verbose: bool = True):
        """
        Initialize timer

        Args:
            name: Timer name, used for identification when printing
            verbose: Whether to automatically print results, if False you need to manually call print_stats()
        """
        self.name = name
        self.verbose = verbose
        self.timings: Dict[str, float] = {}
        self.memory_stats: Dict[str, Dict[str, float]] = {}
        self.start_times: Dict[str, float] = {}
        self.cuda_available = torch.cuda.is_available()

        # Add tracking for last time stats and cumulative stats
        self.step_counts: Dict[str, int] = {}  # Step count for each section
        self.last_timings: Dict[str, float] = {}  # Last execution time for each section
        self.total_timings: Dict[str, float] = (
            {}
        )  # Cumulative execution time for each section
        self.avg_memory_stats: Dict[str, Dict[str, float]] = (
            {}
        )  # Average memory usage for each section

    def start(self, section_name: str) -> None:
        """
        Start timing a specific code section

        Args:
            section_name: Name of the code section
        """
        self.start_times[section_name] = time.time()

        # Record initial GPU memory usage
        if self.cuda_available:
            torch.cuda.synchronize()  # Ensure all CUDA operations are completed
            self.memory_stats[section_name] = {
                "start": torch.cuda.memory_allocated() / (1024**2),  # MB
                "peak": 0.0,
                "end": 0.0,
            }

    def stop(self, section_name: str) -> float:
        """
        Stop timing a specific code section and return execution time

        Args:
            section_name: Name of the code section

        Returns:
            Execution time (milliseconds)
        """
        if section_name not in self.start_times:
            raise ValueError(f"Timing section '{section_name}' was not started")

        # Ensure all GPU operations are completed
        if self.cuda_available:
            torch.cuda.synchronize()

        # Calculate execution time (milliseconds)
        elapsed_time = (
            time.time() - self.start_times[section_name]
        ) * 1000  # Convert to milliseconds
        self.timings[section_name] = elapsed_time

        # Update last time stats and cumulative stats
        self.last_timings[section_name] = elapsed_time

        # Update step count and cumulative time
        if section_name not in self.step_counts:
            self.step_counts[section_name] = 0
            self.total_timings[section_name] = 0.0

        self.step_counts[section_name] += 1
        self.total_timings[section_name] += elapsed_time

        # Record GPU memory usage
        if self.cuda_available:
            current_memory = torch.cuda.memory_allocated() / (1024**2)  # MB
            peak_memory = torch.cuda.max_memory_allocated() / (1024**2)  # MB

            if section_name in self.memory_stats:
                self.memory_stats[section_name]["end"] = current_memory
                self.memory_stats[section_name]["peak"] = peak_memory

                # Update average memory usage
                if section_name not in self.avg_memory_stats:
                    self.avg_memory_stats[section_name] = {
                        "start": 0.0,
                        "end": 0.0,
                        "peak": 0.0,
                        "diff": 0.0,
                    }

                mem_diff = (
                    self.memory_stats[section_name]["end"]
                    - self.memory_stats[section_name]["start"]
                )

                # Update average memory statistics using cumulative average
                count = self.step_counts[section_name]
                self.avg_memory_stats[section_name]["start"] = (
                    (count - 1) * self.avg_memory_stats[section_name]["start"]
                    + self.memory_stats[section_name]["start"]
                ) / count
                self.avg_memory_stats[section_name]["end"] = (
                    (count - 1) * self.avg_memory_stats[section_name]["end"]
                    + self.memory_stats[section_name]["end"]
                ) / count
                self.avg_memory_stats[section_name]["peak"] = (
                    (count - 1) * self.avg_memory_stats[section_name]["peak"]
                    + self.memory_stats[section_name]["peak"]
                ) / count
                self.avg_memory_stats[section_name]["diff"] = (
                    (count - 1) * self.avg_memory_stats[section_name]["diff"] + mem_diff
                ) / count

        # If auto-print is enabled, print statistics for this section
        if self.verbose:
            self._print_section_stats(section_name)

        return elapsed_time

    def _print_section_stats(self, section_name: str) -> None:
        pass  # Keep the last line unchanged
"""
Print statistics for a specific code section

Args:
    section_name: Name of the code section
"""
elapsed_time = self.timings[section_name]
step_count = self.step_counts.get(section_name, 1)
avg_time = self.total_timings.get(section_name, elapsed_time) / step_count

print(f"[{self.name}] {section_name} - Execution time: {elapsed_time:.2f}ms")
print(f"  Last time stats (step {step_count}): {elapsed_time:.2f}ms")
print(
    f"  Cumulative stats (total steps {step_count}): "
    f"Average {avg_time:.2f}ms, Total {self.total_timings.get(
        section_name, elapsed_time):.2f}ms"
)

if self.cuda_available and section_name in self.memory_stats:
    mem_stats = self.memory_stats[section_name]
    mem_diff = mem_stats["end"] - mem_stats["start"]
    print(
        f"  Current GPU memory: Start {mem_stats['start']:.2f}MB, "
        f"End {mem_stats['end']:.2f}MB, Peak {mem_stats['peak']:.2f}MB, "
        f"Net {mem_diff:.2f}MB"
    )

    if section_name in self.avg_memory_stats and step_count > 1:
        avg_mem = self.avg_memory_stats[section_name]
        print(
            f"  Average GPU memory: Start {avg_mem['start']:.2f}MB, "
            f"End {avg_mem['end']:.2f}MB, Peak {avg_mem['peak']:.2f}MB, "
            f"Net {avg_mem['diff']:.2f}MB"
        )


def print_stats(self) -> None:
    """
    Print statistics for all code sections
    """
    if not self.timings:
        print(f"[{self.name}] No timing data recorded")
        return

    print(f"\n===== {self.name} Performance Statistics =====")

    # Calculate total time
    total_time = sum(self.timings.values())

    # Print statistics for each section
    for section_name, elapsed_time in self.timings.items():
        percentage = (
            (elapsed_time / total_time) * 100 if total_time > 0 else 0
        )
        step_count = self.step_counts.get(section_name, 1)
        avg_time = self.total_timings.get(section_name, elapsed_time) / step_count

        print(f"\n[{section_name}]")
        print(
            f"  Last time stats (step {step_count}): "
            f"{elapsed_time:.2f}ms ({percentage:.1f}%)"
        )
        print(
            f"  Cumulative stats (total steps {step_count}): "
            f"Average {avg_time:.2f}ms, Total {self.total_timings.get(
                section_name, elapsed_time):.2f}ms"
        )

        if self.cuda_available and section_name in self.memory_stats:
            mem_stats = self.memory_stats[section_name]
            mem_diff = mem_stats["end"] - mem_stats["start"]
            print(
                f"  Current GPU memory: Start {mem_stats['start']:.2f}MB, "
                f"End {mem_stats['end']:.2f}MB, Peak {mem_stats['peak']:.2f}MB, "
                f"Net {mem_diff:.2f}MB"
            )

            if section_name in self.avg_memory_stats and step_count > 1:
                avg_mem = self.avg_memory_stats[section_name]
                print(
                    f"  Average GPU memory: Start {avg_mem['start']:.2f}MB, "
                    f"End {avg_mem['end']:.2f}MB, Peak {avg_mem['peak']:.2f}MB, "
                    f"Net {avg_mem['diff']:.2f}MB"
                )

    print(f"\nTotal execution time: {total_time:.2f}ms")
    print("=" * (len(self.name) + 18))


@contextlib.contextmanager
def timer_context(
    name: str = "Code Block", timer: Optional[PyTorchTimer] = None, verbose: bool = True
):
    """
    Context manager for timing code blocks

    Usage:
        with timer_context("Matrix Multiplication"):
            result = torch.matmul(a, b)

    Args:
        name: Name of the code block
        timer: Optional PyTorchTimer instance, if not provided a new one will be created
        verbose: Whether to print statistics when exiting the context
    """
    _timer = timer if timer is not None else PyTorchTimer(name=name, verbose=verbose)

    try:
        _timer.start(name)
        yield _timer
    finally:
        _timer.stop(name)


def timer_func(
    func: Optional[Callable] = None, *, name: Optional[str] = None, verbose: bool = True
):
    """
    Decorator for timing function execution

    Usage:
        @timer_func
        def my_function():
            pass

        @timer_func(name="Custom Name", verbose=True)
        def another_function():
            pass

    Args:
        func: The decorated function
        name: Timer name, defaults to function name
        verbose: Whether to print statistics after function execution
    """
    import collections

    Person = collections.namedtuple('Person', 'name gender age weight')
    
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            timer_name = name if name is not None else fn.__name__
            timer = PyTorchTimer(name=timer_name, verbose=verbose)

            timer.start(timer_name)
            try:
                result = fn(*args, **kwargs)
            return result
        finally:
            timer.stop(timer_name)

    return wrapper

if func is None:
    return decorator
return decorator(func)


# Usage example
def example():
    """
    Example function to demonstrate the usage of the PyTorchTimer decorator.
    """
    # Create a timer instance
    timer = PyTorchTimer(name="Matrix Operations Example")

    # Prepare test data
    size = 2000
    a = torch.randn(size, size)
    b = torch.randn(size, size)

    if torch.cuda.is_available():
        a = a.cuda()
        b = b.cuda()

    # Method 1: Directly use start/stop methods
    timer.start("Matrix Multiplication")
    c = torch.matmul(a, b)
    timer.stop("Matrix Multiplication")

    # Method 2: Use context manager
    with timer_context("Matrix Transpose", timer=timer):
        d = b.t()
        e = torch.matmul(a, d)

    # Method 3: Use decorator
    @timer_func(name="Matrix Addition", verbose=False)
    def matrix_add(x, y):
        return x + y

    f = matrix_add(c, e)

    # Print all statistics
    timer.print_stats()
    return f


if __name__ == "__main__":
    example()
